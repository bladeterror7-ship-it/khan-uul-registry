/* ============================================================
   Хан-Уул дүүрэг — Аж ахуйн нэгжийн бүртгэл (app.js)
   ============================================================ */

/* Өгөгдөл хадгалах давхарга.
   - Claude artifact дотор: window.storage (нийтийн сан)
   - Жирийн сервер/локал файл дээр: localStorage
   Сервер рүү шилжихдээ зөвхөн энэ блокийг API дуудлагаар солино. */
const DBX = (() => {
  if (window.storage && typeof window.storage.get === "function") return window.storage;
  const mem = {};
  const ls = (() => { try { localStorage.setItem("__t","1"); localStorage.removeItem("__t"); return localStorage; } catch(e){ return null; } })();
  const get = k => ls ? ls.getItem(k) : (k in mem ? mem[k] : null);
  const put = (k,v) => { ls ? ls.setItem(k,v) : (mem[k]=v); };
  const rm  = k => { ls ? ls.removeItem(k) : delete mem[k]; };
  return {
    async get(k){ const v = get(k); if(v===null || v===undefined) throw new Error("not found: "+k); return {key:k, value:v}; },
    async set(k,v){ put(k,v); return {key:k, value:v}; },
    async delete(k){ rm(k); return {key:k, deleted:true}; },
    async list(){ return {keys:[]}; }
  };
})();

/* ============ Тогтмолууд ============ */
const KEY   = "khanuul_registry_v3";

/* Админы эрхүүд.
   Нууц үг кодод ил бичигдэхгүй — зөвхөн SHA-256 хураангуй хадгална.
   Анх ачаалахад эдгээр эрх DB.admins-д үүсэж, цаашид тэндээс уншина. */
const ADMIN_RESET_PW = "khanuul2026";          // сэргээх үеийн түр нууц үг
const ADMIN_SEED = [
  { user:"enkhsaruul", name:"Н.Энхсаруул", rank:"Хэсгийн байцаагч, цагдаагийн дэслэгч",
    pw:"2d0fd0bcb05abda9539116cb445aeab036162d3cd493d2b11a79ea944129e1d7" },
  { user:"otgontugs", name:"Д.Отгонтөгс", rank:"Хэсгийн байцаагч, цагдаагийн ахлах дэслэгч",
    pw:"98507b55b81e76a5a606d060553a518c0faa0167a8f18b5e90f3b48230db181a" },
  { user:"admin", name:"Системийн нөөц эрх", rank:"Зөвхөн эрх сэргээхэд ашиглана",
    pw:"8bfc8c67e0d51c9e94ef6155a88510e26e482e073b5255cb8ded5e2c51c7c43d" }
];

/* Системийн албан ёсны нэршил */
const SITE_NAME  = "Хан-Уул дүүргийн 2-р хэлтсийн хариуцсан хороодын ААНБ-н нэгдсэн мэдээллийн сан";
const SITE_SHORT = "Хан-Уул дүүрэг — 2-р хэлтсийн ААНБ-н нэгдсэн мэдээллийн сан";

const CATS = [
  "Эмийн сан",
  "Баар / паб",
  "Караоке",
  "Ресторан, зоогийн газар",
  "Хүнсний дэлгүүр (8 нэрийн)",
  "Хүнсний дэлгүүр (6 нэрийн)",
  "Худалдааны төв",
  "Зочид буудал",
  "Гоо сайхны салон",
  "Бариа засал",
  "Саун, массаж",
  "Авто засвар, угаалга",
  "Авто худалдаа",
  "Банк, санхүүгийн байгууллага",
  "Банк бус санхүүгийн байгууллага, ломбард",
  "Биллиард, тоглоомын газар",
  "Фитнес, спорт",
  "Ерөнхий боловсролын сургууль",
  "Цэцэрлэг",
  "Өдөр өнжүүлэх",
  "Их, дээд сургууль",
  "Эрүүл мэндийн байгууллага",
  "СӨХ",
  "Улсын онц чухал байгууллага",
  "Үйлдвэр",
  "Барилга угсралт",
  "Бусад үйлчилгээ"
];
/* Хуучин бүртгэлийн чиглэлийг шинэ жагсаалтад буулгах */
const CAT_MIGRATE = {
  "Боловсролын байгууллага": "Ерөнхий боловсролын сургууль",
  "Хүнсний дэлгүүр (архигүй)": "Хүнсний дэлгүүр (6 нэрийн)"
};
const OWNERS   = ["Хувийн", "Төрийн өмчит", "Орон нутгийн өмчит", "Холимог өмчит", "Гадаадын хөрөнгө оруулалттай"];
const STATUSES = ["Идэвхтэй", "Түр зогссон", "Хаагдсан"];
const APPR     = { ok:"Зөвшөөрөгдсөн", pending:"Хүлээгдэж буй", rejected:"Татгалзсан" };
const KHOROOS  = Array.from({length:25}, (_,i)=>i+1);

/* ============ Туслах ============ */
const $ = s => document.querySelector(s);
const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const hash = s => { let h=5381; for(let i=0;i<s.length;i++) h=((h<<5)+h+s.charCodeAt(i))>>>0; return h.toString(36); };

/* Нууц үгийн хамгаалалт — SHA-256.
   Хуучин бүртгэлүүд сул hash-тай байсан тул нэвтрэхэд таньж, автоматаар шинэ хэлбэрт шилжүүлнэ. */
async function sha(s){
  try{
    const b = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(String(s)));
    return [...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,"0")).join("");
  }catch(e){ return "legacy:" + hash(String(s)); }
}
async function pwVerify(stored, input){
  if(!stored) return false;
  if(stored === hash(input)) return "legacy";
  return (stored === await sha(input)) ? "ok" : false;
}
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const today = () => new Date().toISOString().slice(0,10);
function daysLeft(d){ if(!d) return null; const t=new Date(d); if(isNaN(t)) return null; return Math.round((t-new Date(today()))/86400000); }
function toast(t){ const el=document.createElement("div"); el.className="toast"; el.textContent=t; $("#toastHost").appendChild(el); setTimeout(()=>el.remove(), 2600); }
function fillSelect(sel, arr, val){ if(!sel) return; sel.innerHTML = arr.map(x=>`<option value="${esc(x)}">${esc(x)}</option>`).join(""); if(val!==undefined && val!==null) sel.value = val; }
const okOrgs   = () => DB.orgs.filter(o=>o.appr==="ok");
const pendings = () => DB.orgs.filter(o=>o.appr==="pending");

/* ============ Нууц үг харах товч ============ */
const EYE_ON  = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M1.8 12S5.6 5.2 12 5.2 22.2 12 22.2 12 18.4 18.8 12 18.8 1.8 12 1.8 12Z"/><circle cx="12" cy="12" r="3.1"/></svg>`;
const EYE_OFF = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 3l18 18"/><path d="M10.6 6.6A9.6 9.6 0 0 1 12 6.5c6.4 0 10.2 5.5 10.2 5.5a17 17 0 0 1-3.6 4.1M6.5 8.1A17 17 0 0 0 1.8 12s3.8 5.5 10.2 5.5c1.3 0 2.4-.2 3.5-.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>`;
function attachPwToggles(root){
  (root || document).querySelectorAll('input[type="password"]').forEach(inp=>{
    if(inp.dataset.pwt) return;
    inp.dataset.pwt = "1";
    const wrap = document.createElement("div");
    wrap.className = "pwwrap";
    inp.parentNode.insertBefore(wrap, inp);
    wrap.appendChild(inp);
    const b = document.createElement("button");
    b.type = "button"; b.className = "pweye"; b.innerHTML = EYE_ON;
    b.title = "Нууц үг харах"; b.setAttribute("aria-label", "Нууц үг харах");
    b.onclick = () => {
      const show = inp.type === "password";
      inp.type = show ? "text" : "password";
      b.innerHTML = show ? EYE_OFF : EYE_ON;
      b.title = show ? "Нууц үг нуух" : "Нууц үг харах";
      inp.focus();
    };
    wrap.appendChild(b);
  });
}

/* ============ Өгөгдөл ============ */
let DB = { orgs: [] };
let ME = null;   // {role:'admin'} эсвэл {role:'org', id}

async function loadDB(){
  try{
    const r = await DBX.get(KEY, true);
    DB = JSON.parse(r.value);
    if(!Array.isArray(DB.orgs)) DB.orgs = [];
    DB.orgs.forEach(o=>{
      o.notices = o.notices||[]; o.appr = o.appr||"ok"; o.own = o.own||"Хувийн";
      o.staffN = o.staffN||0; o.camOut = o.camOut ?? ""; o.camIn = o.camIn ?? "";
      o.lat = o.lat ?? ""; o.lng = o.lng ?? "";
      if(CAT_MIGRATE[o.cat]) o.cat = CAT_MIGRATE[o.cat];
    });
  }catch(e){
    /* Анх удаа нээгдэж байна — хоосон бүртгэлээр эхэлнэ */
    DB = { orgs: [] };
  }
  if(seedAdmins()){ try{ await saveDB(); }catch(_){} }
}

/* Админы эрхүүдийг анх удаа үүсгэх. Хуучин нэг эрхийн нууц үг байвал «admin»-д шилжүүлнэ. */
function seedAdmins(){
  if(Array.isArray(DB.admins) && DB.admins.length) return false;
  DB.admins = ADMIN_SEED.map(a => ({ ...a, created:today(), changed:"" }));
  if(DB.adminPw){
    const a = DB.admins.find(x=>x.user==="admin");
    if(a){ a.pw = DB.adminPw; a.changed = today(); }
    delete DB.adminPw;
  }
  return true;
}
const meAdmin = () => (DB.admins||[]).find(x => x.user === (ME && ME.user));
async function saveDB(){
  try{ await DBX.set(KEY, JSON.stringify(DB), true); }
  catch(e){ toast("Хадгалахад алдаа гарлаа. Дахин оролдоно уу."); throw e; }
}

/* ============ Зураг, бичиг баримт ============ */
const MKEY = id => "khanuul_media_" + id;
const mediaCache = {};
async function loadMedia(id){
  if(mediaCache[id]) return mediaCache[id];
  try{ const r = await DBX.get(MKEY(id), true); mediaCache[id] = JSON.parse(r.value); }
  catch(e){ mediaCache[id] = { photos:[], lics:[] }; }
  const m = mediaCache[id];
  if(!Array.isArray(m.photos)) m.photos = [];
  if(!Array.isArray(m.lics))   m.lics   = [];
  /* Хуучин ганц баримтыг олон баримтын жагсаалтад шилжүүлэх */
  if(m.lic && !m.lics.length){ m.lics.push(m.lic); }
  delete m.lic;
  return m;
}
async function saveMedia(id, m){
  mediaCache[id] = m;
  try{ await DBX.set(MKEY(id), JSON.stringify(m), true); }
  catch(e){ toast("Файл хадгалахад алдаа гарлаа. Хэмжээг багасгаад дахин оролдоно уу."); throw e; }
}
function shrinkImage(file, max=1100, q=.72){
  return new Promise((res, rej)=>{
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const s = Math.min(1, max/Math.max(img.width, img.height));
        const c = document.createElement("canvas");
        c.width = Math.round(img.width*s); c.height = Math.round(img.height*s);
        c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
        res(c.toDataURL("image/jpeg", q));
      };
      img.onerror = rej; img.src = fr.result;
    };
    fr.onerror = rej; fr.readAsDataURL(file);
  });
}
function cropPhoto34(file, w=300, h=400, q=.74){
  return new Promise((res, rej)=>{
    const fr = new FileReader();
    fr.onload = () => {
      const img = new Image();
      img.onload = () => {
        const c = document.createElement("canvas");
        c.width = w; c.height = h;
        const ctx = c.getContext("2d");
        ctx.fillStyle = "#fff"; ctx.fillRect(0,0,w,h);
        const s = Math.max(w/img.width, h/img.height);      // дүүргэж тайрна
        const dw = img.width*s, dh = img.height*s;
        ctx.drawImage(img, (w-dw)/2, (h-dh)/2, dw, dh);      // голлуулна
        res(c.toDataURL("image/jpeg", q));
      };
      img.onerror = rej; img.src = fr.result;
    };
    fr.onerror = rej; fr.readAsDataURL(file);
  });
}
function readAsData(file){
  return new Promise((res, rej)=>{ const fr=new FileReader(); fr.onload=()=>res(fr.result); fr.onerror=rej; fr.readAsDataURL(file); });
}
function downloadBlob(content, type, name){
  const url = URL.createObjectURL(new Blob([content], {type}));
  const a = document.createElement("a"); a.href=url; a.download=name; a.click();
  setTimeout(()=>URL.revokeObjectURL(url), 5000);
}
function openData(dataUrl, name){
  const bin = atob(dataUrl.split(",")[1]);
  const type = dataUrl.slice(5, dataUrl.indexOf(";"));
  const arr = new Uint8Array(bin.length);
  for(let i=0;i<bin.length;i++) arr[i] = bin.charCodeAt(i);
  downloadBlob(arr, type, name || "file");
}

/* ============ Ажилчдын бүртгэл ============ */
const SKEY = id => "khanuul_staff_" + id;
const staffCache = {};
const POSITIONS = ["Захирал","Менежер","Нягтлан бодогч","Худалдагч","Кассчин","Тогооч","Үйлчлэгч","Эмч","Эм зүйч","Бариа заслын мэргэжилтэн","Массажист","Гоо сайханч","Багш","Харуул, жижүүр","Инженер, техникч","Жолооч","Бусад"];
const STAFF_STATUS = ["Ажиллаж байгаа","Чөлөөлөгдсөн"];

async function loadStaff(id){
  if(staffCache[id]) return staffCache[id];
  try{ const r = await DBX.get(SKEY(id), true); const v = JSON.parse(r.value); staffCache[id] = Array.isArray(v) ? v : []; }
  catch(e){ staffCache[id] = []; }
  return staffCache[id];
}
async function saveStaff(id, list, org){
  staffCache[id] = list;
  try{ await DBX.set(SKEY(id), JSON.stringify(list), true); }
  catch(e){ toast("Ажилтны бүртгэл хадгалахад алдаа гарлаа."); throw e; }
  if(org){ org.staffN = list.filter(s=>s.status!=="Чөлөөлөгдсөн").length; await saveDB(); }
}

/* ============ Мэдэгдэл ============ */
function pushNotice(o, key, kind, text, imgs){
  o.notices = o.notices || [];
  if(o.notices.some(n=>n.key===key)) return false;
  o.notices.unshift({ id:uid(), key, kind, text, imgs:Array.isArray(imgs)?imgs:[], date:today(), read:false });
  return true;
}
async function ensureNotices(){
  let changed = false;
  DB.orgs.forEach(o=>{
    if(o.appr!=="ok") return;
    const d = daysLeft(o.licEnd);
    if(d===null) return;
    if(d<0)
      changed = pushNotice(o, "exp:"+o.licEnd, "bad",
        `Тусгай зөвшөөрлийн хугацаа ${o.licEnd}-нд дууссан. Үйл ажиллагаагаа үргэлжлүүлэхийн тулд зөвшөөрлөө сунгуулж, шинэ бичиг баримтаа энэ хуудсанд байршуулна уу.`) || changed;
    else if(d<=30)
      changed = pushNotice(o, "w30:"+o.licEnd, "warn",
        `Тусгай зөвшөөрлийн хугацаа дуусахад ${d} хоног үлдлээ (${o.licEnd}). Сунгуулах хүсэлтээ 2-р хэлтсийн бүртгэлийн албанд хүргүүлнэ үү.`) || changed;
    else if(d<=60)
      changed = pushNotice(o, "w60:"+o.licEnd, "warn",
        `Тусгай зөвшөөрлийн хугацаа дуусахад ${d} хоног үлдлээ (${o.licEnd}).`) || changed;
  });
  if(changed){ try{ await saveDB(); }catch(e){} }
}
const unread = o => (o.notices||[]).filter(n=>!n.read).length;
/* Мэдэгдэлд хавсаргасан зураг */
function noticeImgs(n){
  const list = (n && Array.isArray(n.imgs)) ? n.imgs : [];
  if(!list.length) return "";
  return `<div class="gallery" style="margin-top:9px">${list.map((p,i)=>
    `<div class="shot"><img src="${p}" alt="Хавсралт ${i+1}"></div>`).join("")}</div>`;
}

/* ============ Нэвтрэх дэлгэц ============ */
function renderAuthStats(){
  const list = okOrgs();
  const rows = [
    ["Бүртгэлтэй нэгж", list.length],
    ["Идэвхтэй үйл ажиллагаатай", list.filter(o=>o.status==="Идэвхтэй").length],
    ["Хамрагдсан хороо", new Set(list.map(o=>o.khoroo)).size],
    ["Үйл ажиллагааны чиглэл", new Set(list.map(o=>o.cat)).size]
  ];
  $("#authStats").innerHTML = rows.map(([a,b])=>`<div class="stat-row"><b class="num">${b}</b><span>${a}</span></div>`).join("");
}
function authMsg(text, kind="err"){ $("#authMsg").innerHTML = text ? `<div class="msg ${kind}">${esc(text)}</div>` : ""; }

document.querySelectorAll(".tab").forEach(t=>t.onclick=()=>{
  document.querySelectorAll(".tab").forEach(x=>x.classList.toggle("on", x===t));
  const map = { login:"#fLogin", reg:"#fReg", admin:"#fAdmin" };
  document.querySelectorAll(".pane").forEach(p=>p.classList.add("hidden"));
  $(map[t.dataset.tab]).classList.remove("hidden");
  authMsg("");
});

$("#fLogin").onsubmit = async e => {
  e.preventDefault();
  const reg = $("#li_reg").value.trim(), pw = $("#li_pw").value;
  const o = DB.orgs.find(x=>x.reg===reg);
  const v = o ? await pwVerify(o.pw, pw) : false;
  if(!v) return authMsg("Байгууллагын регистр эсвэл нууц үг буруу байна.");
  if(v==="legacy"){ o.pw = await sha(pw); try{ await saveDB(); }catch(_){} }
  ME = { role:"org", id:o.id }; enterApp();
};

$("#fReg").onsubmit = async e => {
  e.preventDefault();
  const reg = $("#rg_reg").value.trim();
  if(!/^\d{6,8}$/.test(reg)) return authMsg("Байгууллагын регистр 6–8 оронтой тоо байна.");
  if(DB.orgs.some(x=>x.reg===reg)) return authMsg("Энэ регистрийн дугаар аль хэдийн бүртгэгдсэн байна.");
  if($("#rg_pw").value.length<4) return authMsg("Нууц үг дор хаяж 4 тэмдэгт байна.");
  if($("#rg_pw").value !== $("#rg_pw2").value) return authMsg("Нууц үг таарахгүй байна.");
  const o = {
    id:uid(), name:$("#rg_name").value.trim(), reg,
    cat:$("#rg_cat").value, own:$("#rg_own").value,
    district:"Хан-Уул", khoroo:Number($("#rg_khoroo").value), addr:$("#rg_addr").value.trim(),
    lat:$("#rg_lat").value.trim(), lng:$("#rg_lng").value.trim(),
    area:"", staff:"", hours:"", lic:"", licEnd:"", dir:$("#rg_dir").value.trim(),
    phone:$("#rg_phone").value.trim(), mail:"", since:"", status:"Идэвхтэй", note:"",
    appr:"pending", apprAt:"", apprNote:"",
    pw:await sha($("#rg_pw").value), created:today(), notices:[]
  };
  pushNotice(o, "req:"+o.id, "info",
    "Бүртгүүлэх хүсэлт хүлээн авлаа. Хан-Уул дүүргийн 2-р хэлтсийн бүртгэлийн алба хянаж, зөвшөөрөл олгосны дараа таны бүртгэл системд бүрэн идэвхжинэ. Хүлээгдэж байх хугацаанд мэдээлэл, зураг, зөвшөөрлийн баримтаа оруулж болно.");
  DB.orgs.push(o); await saveDB();
  ME = { role:"org", id:o.id }; enterApp();
  toast("Хүсэлт илгээгдлээ. Админы зөвшөөрлийг хүлээнэ үү.");
};

$("#fAdmin").onsubmit = async e => {
  e.preventDefault();
  const u = $("#ad_user").value.trim().toLowerCase();
  const a = (DB.admins||[]).find(x => x.user.toLowerCase() === u);
  const got = await sha($("#ad_pw").value);
  if(!a || got !== a.pw) return authMsg("Админ код эсвэл нууц үг буруу байна.");
  ME = { role:"admin", user:a.user, name:a.name, rank:a.rank }; enterApp();
};

$("#btnOut").onclick = () => {
  ME = null; $("#app").classList.add("hidden"); $("#auth").classList.remove("hidden");
  $("#li_pw").value=""; $("#ad_pw").value=""; renderAuthStats(); authMsg("");
};

function enterApp(){
  $("#auth").classList.add("hidden"); $("#app").classList.remove("hidden");
  render();
}

/* ============ Дүрслэл ============ */
function render(){
  if(!ME) return;
  if(ME.role==="admin"){
    const p = pendings().length;
    $("#roleLine").textContent = SITE_NAME + " — бүх байгууллагын мэдээлэл";
    $("#whoBox").innerHTML =
      `<span class="role">Админ${p?`<span class="badge">${p} хүсэлт</span>`:""}</span>`
      + `<b>${esc(ME.name||"")}</b>`
      + `<span>${esc(ME.rank||"2-р хэлтсийн бүртгэлийн алба")}</span>`;
    renderAdmin();
  }else{
    const o = DB.orgs.find(x=>x.id===ME.id);
    if(!o){ $("#btnOut").click(); return; }
    const un = unread(o);
    $("#roleLine").textContent = "Байгууллагын хуудас — зөвхөн өөрийн мэдээлэл";
    $("#whoBox").innerHTML = `<b>${esc(o.name)}${un?`<span class="badge">${un} мэдэгдэл</span>`:""}</b>Регистр №${esc(o.reg)}`;
    renderOrg(o);
  }
}

/* ---------- Шошго ---------- */
function statusPill(s){
  const k = s==="Идэвхтэй" ? "ok" : s==="Түр зогссон" ? "warn" : "bad";
  return `<span class="pill ${k}">${esc(s)}</span>`;
}
function apprPill(o){
  const k = o.appr==="ok" ? "ok" : o.appr==="pending" ? "warn" : "bad";
  return `<span class="pill ${k}">${esc(APPR[o.appr]||o.appr)}</span>`;
}
function licPill(o){
  if(!o.lic && !o.licEnd) return `<span class="pill neutral">Бүртгээгүй</span>`;
  const d = daysLeft(o.licEnd);
  if(d===null) return `<span class="pill neutral">${esc(o.lic)}</span>`;
  if(d<0) return `<span class="pill bad">Хугацаа дууссан</span>`;
  if(d<=60) return `<span class="pill warn">${d} хоног үлдсэн</span>`;
  return `<span class="pill ok">Хүчинтэй</span>`;
}
function geoLink(o){
  if(!o.lat || !o.lng) return "";
  const q = `${o.lat},${o.lng}`;
  return `${esc(o.lat)}, ${esc(o.lng)} &nbsp; <a href="https://www.google.com/maps?q=${encodeURIComponent(q)}" target="_blank" rel="noopener">газрын зураг дээр харах</a>`;
}
function kvTable(o){
  const rows = [
    ["Байгууллагын нэр", o.name],
    ["Байгууллагын регистр", o.reg],
    ["Үйл ажиллагааны чиглэл", o.cat],
    ["Өмчийн хэлбэр", o.own],
    ["Байршил", `${o.district} дүүрэг, ${o.khoroo}-р хороо`],
    ["Дэлгэрэнгүй хаяг", o.addr],
    ["Өргөрөг (latitude)", o.lat],
    ["Уртраг (longitude)", o.lng],
    ["Солбицол", geoLink(o)],
    ["Үйл ажиллагааны талбай", o.area ? o.area+" м²" : ""],
    ["Ажиллагсдын тоо", o.staff],
    ["Ажиллах цагийн хуваарь", o.hours],
    ["Гадна камерын тоо", o.camOut===""||o.camOut===undefined ? "" : String(o.camOut)],
    ["Дотор камерын тоо", o.camIn===""||o.camIn===undefined ? "" : String(o.camIn)],
    ["Нийт камер", (Number(o.camOut)||0)+(Number(o.camIn)||0) ? String((Number(o.camOut)||0)+(Number(o.camIn)||0)) : ""],
    ["Тусгай зөвшөөрлийн дугаар", o.lic],
    ["Зөвшөөрөл дуусах огноо", o.licEnd ? `${esc(o.licEnd)} &nbsp; ${licPill(o)}` : ""],
    ["Захирал / эзэмшигч", o.dir],
    ["Утас", o.phone],
    ["И-мэйл", o.mail],
    ["Үйл ажиллагаа эхэлсэн", o.since],
    ["Төлөв", statusPill(o.status)],
    ["Бүртгэлийн төлөв", apprPill(o)],
    ["Тэмдэглэл", o.note],
    ["Бүртгүүлсэн огноо", o.created]
  ];
  return `<dl class="kv">${rows.map(([k,v])=>`<dt>${k}</dt><dd>${v ? (String(v).includes("<") ? v : esc(v)) : '<span class="note">—</span>'}</dd>`).join("")}</dl>`;
}

/* ---------- Байгууллагын хуудас ---------- */
function mediaPanels(){
  return `
    <div class="panel">
      <h3>Тусгай зөвшөөрлийн баримт</h3>
      <div class="body">
        <div class="gallery" id="licBox"><span class="note">Ачаалж байна…</span></div>
        <div style="margin-top:12px"><label class="upl">Баримт нэмэх<input type="file" accept="image/*,application/pdf" multiple id="upLic"></label></div>
        <p class="note" style="margin-top:8px">Хамгийн ихдээ <b>4</b> баримт (зураг эсвэл PDF). Дугаар, дуусах огноог “Мэдээлэл засах” хэсгээс оруулна.</p>
      </div>
    </div>
    <div class="panel">
      <h3>Байгууллагын зураг</h3>
      <div class="body">
        <div class="gallery" id="gal"><span class="note">Ачаалж байна…</span></div>
        <div style="margin-top:12px"><label class="upl">Зураг нэмэх<input type="file" accept="image/*" multiple id="upPhoto"></label></div>
        <p class="note" style="margin-top:8px">Хамгийн ихдээ 6 зураг. Зургийг автоматаар шахаж хадгална.</p>
      </div>
    </div>`;
}

function renderOrg(o){
  if(o.appr!=="ok") return renderOrgPending(o);
  const notices = (o.notices||[]).slice(0,12);
  const un = unread(o);
  const d = daysLeft(o.licEnd);
  const licCell = d===null
    ? `<b style="font-size:19px;padding-top:6px"><span class="pill neutral">Огноо оруулаагүй</span></b><span>Тусгай зөвшөөрөл</span>`
    : d<0
      ? `<b class="num" style="color:var(--bad)">${-d}</b><span>Зөвшөөрөл дууссанаас хойш, хоног</span>`
      : `<b class="num" style="color:${d<=60?"var(--warn)":"inherit"}">${d}</b><span>Зөвшөөрөл дуусахад үлдсэн хоног</span>`;

  $("#view").innerHTML = `
    <div class="panel">
      <h3>Мэдэгдэл ${un?`<span class="badge">${un} шинэ</span>`:""}</h3>
      <div class="body">
        ${notices.length ? notices.map(n=>`
          <div class="notice ${esc(n.kind)}">
            ${n.read?"":'<span class="dot"></span>'}
            <div><div>${esc(n.text)}</div>${noticeImgs(n)}<div class="when">${esc(n.date)}${n.read?"":" · шинэ"}</div></div>
          </div>`).join("") : `<p class="note">Одоогоор мэдэгдэл алга.</p>`}
        ${un ? `<button class="btn ghost sm" id="oRead" style="margin-top:8px">Бүгдийг уншсан болгох</button>` : ""}
      </div>
    </div>

    <div class="strip">
      <div><b>${esc(o.khoroo)}</b><span>${esc(o.district)} дүүрэг, дугаар хороо</span></div>
      <div><b class="num">${esc(o.staff||"—")}</b><span>Ажиллагсдын тоо</span></div>
      <div><b class="num">${esc(o.area||"—")}</b><span>Талбай, м²</span></div>
      <div>${licCell}</div>
    </div>

    <div class="panel">
      <h3>Ажилчдын бүртгэл</h3>
      <div class="body">
        <div class="khoroo-pick" style="justify-content:space-between">
          <div class="count-tag" id="staffMeta">Ачаалж байна…</div>
          <div class="acts" style="display:flex;gap:9px;flex-wrap:wrap">
            <button class="btn ghost sm" id="staffCsv">Ажилчдын CSV</button>
            <button class="btn sm" id="staffAdd">Ажилтан нэмэх</button>
          </div>
        </div>
        <div class="tblwrap" id="staffBox"></div>
      </div>
    </div>

    ${mediaPanels()}

    <div class="panel">
      <h3>Бүртгэлийн мэдээлэл</h3>
      <div class="body">${kvTable(o)}</div>
      <div style="padding:14px 18px;border-top:1px solid var(--line-soft);display:flex;gap:9px;flex-wrap:wrap">
        <button class="btn" id="oEdit">Мэдээлэл засах</button>
        <button class="btn ghost" id="oAnket">Анкет татах</button>
        <button class="btn ghost" id="oCsv">Excel (CSV) татах</button>
        <button class="btn ghost" id="oPw">Нууц үг солих</button>
      </div>
    </div>
    <p class="note">Таны оруулсан мэдээлэл, зураг 2-р хэлтсийн бүртгэлийн албанд харагдана. Бусад байгууллага таны мэдээллийг харах боломжгүй.</p>
  `;
  $("#oEdit").onclick  = () => orgForm(o);
  $("#oPw").onclick    = () => pwForm(o);
  $("#oCsv").onclick   = () => exportCSV([o], `burtgel_${o.reg}.csv`);
  $("#oAnket").onclick = () => downloadAnket(o);
  if($("#oRead")) $("#oRead").onclick = async () => { (o.notices||[]).forEach(n=>n.read=true); await saveDB(); render(); };
  $("#staffAdd").onclick = () => staffForm(o, null);
  $("#staffCsv").onclick = async () => exportStaffCSV(o, await loadStaff(o.id));
  paintOrgMedia(o);
  paintStaff(o, true);
}

function renderOrgPending(o){
  const pending = o.appr==="pending";
  $("#view").innerHTML = `
    <div class="msg ${pending?"":"err"}" style="${pending?"background:var(--gold-soft);color:var(--warn);border-left-color:var(--gold)":""}">
      ${pending
        ? "Таны бүртгүүлэх хүсэлт админы хяналтад байна. Зөвшөөрөл олгогдтол таны бүртгэл нийтийн санд харагдахгүй. Хүлээх хугацаандаа мэдээлэл, зураг, зөвшөөрлийн баримтаа бүрэн оруулбал хянах ажил хурдан явагдана."
        : "Таны хүсэлтийг админ татгалзсан байна. Шалтгаан: " + (o.apprNote || "тодорхойлоогүй") + ". Мэдээллээ засаад дахин хүсэлт илгээх боломжтой."}
    </div>

    <div class="strip">
      <div><b style="font-size:19px;padding-top:6px">${apprPill(o)}</b><span>Бүртгэлийн төлөв</span></div>
      <div><b>${esc(o.khoroo)}</b><span>${esc(o.district)} дүүрэг, дугаар хороо</span></div>
      <div><b style="font-size:16px;padding-top:9px">${esc(o.cat)}</b><span>Үйл ажиллагааны чиглэл</span></div>
      <div><b style="font-size:16px;padding-top:9px">${esc(o.own)}</b><span>Өмчийн хэлбэр</span></div>
    </div>

    ${mediaPanels()}

    <div class="panel">
      <h3>Хүсэлтэд оруулсан мэдээлэл</h3>
      <div class="body">${kvTable(o)}</div>
      <div style="padding:14px 18px;border-top:1px solid var(--line-soft);display:flex;gap:9px;flex-wrap:wrap">
        <button class="btn" id="oEdit">Мэдээлэл засах</button>
        ${o.appr==="rejected" ? `<button class="btn" id="oAgain">Дахин хүсэлт илгээх</button>` : ""}
        <button class="btn ghost" id="oPw">Нууц үг солих</button>
      </div>
    </div>`;
  $("#oEdit").onclick = () => orgForm(o);
  $("#oPw").onclick = () => pwForm(o);
  if($("#oAgain")) $("#oAgain").onclick = async () => {
    o.appr = "pending"; o.apprNote = "";
    pushNotice(o, "req:"+uid(), "info", "Бүртгэлийн хүсэлтээ дахин илгээлээ. Админы хариуг хүлээнэ үү.");
    await saveDB(); render(); toast("Хүсэлтийг дахин илгээлээ.");
  };
  paintOrgMedia(o);
}

async function paintOrgMedia(o){
  const m = await loadMedia(o.id);

  const box = $("#licBox"); if(!box) return;
  box.innerHTML = m.lics.length
    ? m.lics.map((L,i)=>`
        <div class="shot">
          ${L.data.startsWith("data:image")
            ? `<img src="${L.data}" alt="Тусгай зөвшөөрөл ${i+1}">`
            : `<span class="photo34 ph" style="width:100%;aspect-ratio:4/3;display:flex;align-items:center;justify-content:center">📄 PDF</span>`}
          <button data-licdel="${i}">Устгах</button>
          <div class="reg" style="padding:6px 2px 0">${esc(L.name||("Баримт "+(i+1)))}<br>${esc(L.at||"")}</div>
          <button class="btn ghost sm" data-licget="${i}" style="margin-top:4px">Татаж авах</button>
        </div>`).join("")
    : `<p class="note">Зөвшөөрлийн баримт байршуулаагүй байна.</p>`;

  box.querySelectorAll("[data-licdel]").forEach(b=>b.onclick = async () => {
    m.lics.splice(+b.dataset.licdel, 1);
    await saveMedia(o.id, m); paintOrgMedia(o); toast("Баримтыг устгалаа.");
  });
  box.querySelectorAll("[data-licget]").forEach(b=>b.onclick = () => {
    const L = m.lics[+b.dataset.licget]; if(L) openData(L.data, L.name);
  });

  if($("#upLic")) $("#upLic").onchange = async e => {
    const files = [...e.target.files];
    if(!files.length) return;
    if(m.lics.length + files.length > 4) return toast("Хамгийн ихдээ 4 баримт байршуулна.");
    for(const f of files){
      if(f.size > 4*1024*1024){ toast(`${f.name} — 4 МБ-аас их байна.`); continue; }
      const data = f.type.startsWith("image/") ? await shrinkImage(f, 1400, .78) : await readAsData(f);
      m.lics.push({ name:f.name, data, at:today() });
    }
    await saveMedia(o.id, m); paintOrgMedia(o); toast("Зөвшөөрлийн баримт хадгалагдлаа.");
  };

  const gal = $("#gal"); if(!gal) return;
  gal.innerHTML = m.photos.length
    ? m.photos.map((p,i)=>`<div class="shot"><img src="${p}" alt="Байгууллагын зураг ${i+1}"><button data-i="${i}">Устгах</button></div>`).join("")
    : `<p class="note">Зураг оруулаагүй байна.</p>`;
  gal.querySelectorAll("[data-i]").forEach(b=>b.onclick = async () => {
    m.photos.splice(+b.dataset.i,1); await saveMedia(o.id,m); paintOrgMedia(o); toast("Зургийг устгалаа.");
  });
  $("#upPhoto").onchange = async e => {
    const files = [...e.target.files];
    if(!files.length) return;
    if(m.photos.length + files.length > 6) return toast("Хамгийн ихдээ 6 зураг байршуулна.");
    for(const f of files){ if(f.type.startsWith("image/")) m.photos.push(await shrinkImage(f)); }
    await saveMedia(o.id, m); paintOrgMedia(o); toast("Зураг хадгалагдлаа.");
  };
}

/* ---------- Админ хуудас ---------- */
let F = { q:"", cat:"", own:"", khoroo:"", status:"", appr:"", sort:"name", dir:1 };
let KH = "";  // хороогоор харах хэсгийн сонголт

function renderAdmin(){
  const list = okOrgs();
  const expiring = list.filter(o=>{ const d=daysLeft(o.licEnd); return d!==null && d<=60; }).length;
  const reqs = pendings();

  $("#view").innerHTML = `
    ${reqs.length ? `
    <div class="panel">
      <h3>Бүртгүүлэх хүсэлт <span class="badge">${reqs.length}</span></h3>
      <div class="body">
        ${reqs.map(o=>`
          <div class="req">
            <div>
              <div class="name">${esc(o.name)}</div>
              <div class="meta">№${esc(o.reg)} · ${esc(o.cat)} · ${esc(o.own)} · ${esc(o.khoroo)}-р хороо · ${esc(o.phone)||"утас оруулаагүй"} · ${esc(o.created)}</div>
            </div>
            <div class="acts">
              <button class="btn ghost sm" data-see="${o.id}">Дэлгэрэнгүй</button>
              <button class="btn ghost sm" data-no="${o.id}">Татгалзах</button>
              <button class="btn sm" data-yes="${o.id}">Зөвшөөрөх</button>
            </div>
          </div>`).join("")}
      </div>
    </div>` : ""}

    <div class="strip">
      <div><b class="num">${list.length}</b><span>Зөвшөөрөгдсөн нэгж</span></div>
      <div><b class="num">${list.filter(o=>o.status==="Идэвхтэй").length}</b><span>Идэвхтэй үйл ажиллагаатай</span></div>
      <div><b class="num">${expiring}</b><span>Зөвшөөрөл дуусах / дууссан</span></div>
      <div><b class="num">${reqs.length}</b><span>Хүлээгдэж буй хүсэлт</span></div>
    </div>

    <div class="toolbar">
      <div class="field" style="flex:2"><label>Хайх</label><input id="fq" placeholder="нэр, бүртгэлийн дугаар, хаяг, захирал" value="${esc(F.q)}"></div>
      <div class="field"><label>Чиглэл</label><select id="fcat"></select></div>
      <div class="field"><label>Өмчийн хэлбэр</label><select id="fown"></select></div>
      <div class="field"><label>Хороо</label><select id="fkh"></select></div>
      <div class="field"><label>Төлөв</label><select id="fst"></select></div>
      <div class="field"><label>Бүртгэл</label><select id="fap"></select></div>
      <button class="btn ghost" id="fclear">Шүүлт цэвэрлэх</button>
      <button class="btn ghost" id="bcsv">CSV татах</button>
      <button class="btn" id="badd">Байгууллага нэмэх</button>
    </div>

    <div class="panel">
      <h3 id="listTitle"></h3>
      <div class="tblwrap" id="tbl"></div>
    </div>

    <div class="panel">
      <h3>Админы эрх</h3>
      <div class="body">
        <div class="khoroo-pick" style="justify-content:space-between">
          <div class="count-tag">Нийт ${(DB.admins||[]).length} эрх · нэвтэрсэн: <b>${esc(ME.name||"")}</b></div>
          <button class="btn sm" id="bAdmAdd">Админ эрх нэмэх</button>
        </div>
        <div class="tblwrap" id="admBox"></div>
        <p class="note" style="margin-top:11px">Эрх бүр өөрийн нэвтрэх нэр, нууц үгтэй. Нууц үгээ мартвал өөр админ «Нууц үг сэргээх» дарж түр нууц үг өгнө.</p>
      </div>
    </div>

    <div class="panel">
      <h3>Газрын зураг</h3>
      <div class="body">
        <div id="map" style="height:470px;border:1px solid var(--line);border-radius:8px"></div>
        <p class="note" id="mapNote" style="margin-top:10px"></p>
      </div>
    </div>

    <div class="panel">
      <h3>Өгөгдөл, нөөцлөлт</h3>
      <div class="body">
        <div class="count-tag" id="stoMeter"></div>
        <div style="display:flex;gap:9px;flex-wrap:wrap;margin-top:13px">
          <button class="btn" id="bBackup">Бүх өгөгдлийг нөөцлөх</button>
          <label class="upl">Нөөцөөс сэргээх<input type="file" accept=".json,application/json" id="bRestore"></label>
          <label class="upl">CSV-ээс импортлох<input type="file" accept=".csv,text/csv" id="bImport"></label>
          <button class="btn ghost" id="bTpl">CSV загвар татах</button>
          <button class="btn ghost" id="bAdmPw">Миний нууц үг солих</button>
        </div>
        <p class="note" style="margin-top:11px">
          Мэдээлэл одоогоор энэ браузерт хадгалагдаж байгаа тул долоо хоног бүр нөөцлөхийг зөвлөе.
          Нөөц файл нь зураг, баримт, ажилчдын бүртгэлийг бүгдийг агуулна — ирээдүйд өгөгдлийн сан руу шилжүүлэхэд шууд ашиглагдана.
        </p>
      </div>
    </div>

    <div class="panel">
      <h3>Хороогоор харах</h3>
      <div class="body">
        <div class="khoroo-pick">
          <div class="field"><label>Хороо сонгох</label><select id="khSel"></select></div>
          <div class="count-tag" id="khCount"></div>
        </div>
        <div class="tblwrap" id="khList"></div>
      </div>
    </div>

    <div class="panel">
      <h3>Үйл ажиллагааны чиглэлээр</h3>
      <div class="body"><div class="bars" id="byCat"></div></div>
    </div>
    <div class="panel">
      <h3>Өмчийн хэлбэрээр</h3>
      <div class="body"><div class="bars" id="byOwn"></div></div>
    </div>
    <div class="panel">
      <h3>Хороогоор</h3>
      <div class="body"><div class="bars" id="byKh"></div></div>
    </div>
  `;

  // хүсэлтийн товчнууд
  $("#view").querySelectorAll("[data-yes]").forEach(b=>b.onclick=()=>approveOrg(b.dataset.yes));
  $("#view").querySelectorAll("[data-no]").forEach(b=>b.onclick=()=>rejectForm(b.dataset.no));
  $("#view").querySelectorAll("[data-see]").forEach(b=>b.onclick=()=>detail(b.dataset.see));

  fillSelect($("#fcat"), ["Бүгд", ...CATS], F.cat||"Бүгд");
  fillSelect($("#fown"), ["Бүгд", ...OWNERS], F.own||"Бүгд");
  fillSelect($("#fkh"),  ["Бүгд", ...KHOROOS.map(k=>k+"-р хороо")], F.khoroo ? F.khoroo+"-р хороо" : "Бүгд");
  fillSelect($("#fst"),  ["Бүгд", ...STATUSES], F.status||"Бүгд");
  fillSelect($("#fap"),  ["Бүгд", ...Object.values(APPR)], F.appr ? APPR[F.appr] : "Бүгд");

  $("#fq").oninput    = e => { F.q = e.target.value; paintTable(); };
  $("#fcat").onchange = e => { F.cat = e.target.value==="Бүгд"?"":e.target.value; paintTable(); };
  $("#fown").onchange = e => { F.own = e.target.value==="Бүгд"?"":e.target.value; paintTable(); };
  $("#fkh").onchange  = e => { F.khoroo = e.target.value==="Бүгд"?"":parseInt(e.target.value); paintTable(); };
  $("#fst").onchange  = e => { F.status = e.target.value==="Бүгд"?"":e.target.value; paintTable(); };
  $("#fap").onchange  = e => {
    const v = e.target.value;
    F.appr = v==="Бүгд" ? "" : Object.keys(APPR).find(k=>APPR[k]===v) || "";
    paintTable();
  };
  $("#fclear").onclick = () => { F = {q:"",cat:"",own:"",khoroo:"",status:"",appr:"",sort:F.sort,dir:F.dir}; renderAdmin(); };
  $("#bcsv").onclick   = () => exportCSV(filtered(), "khan_uul_burtgel.csv");
  $("#badd").onclick   = () => orgForm(null);

  $("#bBackup").onclick  = () => backupAll();
  $("#bTpl").onclick     = () => csvTemplate();
  $("#bAdmPw").onclick   = () => adminPwForm();
  $("#bAdmAdd").onclick  = () => adminAddForm();
  $("#bRestore").onchange = e => { const f = e.target.files[0]; e.target.value = ""; if(f) restoreAll(f); };
  $("#bImport").onchange  = e => { const f = e.target.files[0]; e.target.value = ""; if(f) importCSV(f); };

  fillSelect($("#khSel"), ["— сонгох —", ...KHOROOS.map(k=>k+"-р хороо")], KH || "— сонгох —");
  $("#khSel").onchange = e => { KH = e.target.value==="— сонгох —" ? "" : e.target.value; paintKhoroo(); };

  paintTable(); paintKhoroo(); paintBars(); paintStorage(); paintAdmins();
}

async function approveOrg(id){
  const o = DB.orgs.find(x=>x.id===id); if(!o) return;
  o.appr = "ok"; o.apprAt = today(); o.apprNote = "";
  pushNotice(o, "appr:"+today()+":"+o.id, "info",
    "Бүртгэлийн хүсэлт зөвшөөрөгдлөө. Таны байгууллага 2-р хэлтсийн хариуцсан хороодын ААНБ-н нэгдсэн мэдээллийн санд албан ёсоор бүртгэгдлээ. Мэдээллээ бүрэн гүйцэд байлгаж, зөвшөөрлийн хугацааг хянаж байхыг анхаарна уу.");
  await saveDB(); await ensureNotices(); render(); toast("Зөвшөөрөл олголоо.");
}

function rejectForm(id){
  const o = DB.orgs.find(x=>x.id===id); if(!o) return;
  openModal(`Хүсэлт татгалзах — ${o.name}`, `
    <div class="field"><label>Татгалзсан шалтгаан</label>
      <textarea id="rj_text" rows="3" placeholder="Жишээ: Улсын бүртгэлийн гэрчилгээний хуулбар дутуу, өргөрөг уртраг оруулаагүй байна."></textarea></div>
    <p class="note">Шалтгаан байгууллагад мэдэгдэл болж очих бөгөөд тэд мэдээллээ засаад дахин хүсэлт илгээх боломжтой.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Татгалзах", cls:"danger", act:async ()=>{
      const t = $("#rj_text").value.trim();
      if(!t) return toast("Шалтгаанаа бичнэ үү.");
      o.appr = "rejected"; o.apprNote = t;
      pushNotice(o, "rej:"+uid(), "bad", "Бүртгэлийн хүсэлтийг татгалзлаа. Шалтгаан: " + t);
      await saveDB(); closeModal(); render(); toast("Хүсэлтийг татгалзлаа.");
    }}
  ]);
}

function filtered(){
  const q = F.q.trim().toLowerCase();
  const list = DB.orgs.filter(o=>{
    if(F.cat && o.cat!==F.cat) return false;
    if(F.own && o.own!==F.own) return false;
    if(F.khoroo && Number(o.khoroo)!==F.khoroo) return false;
    if(F.status && o.status!==F.status) return false;
    if(F.appr && o.appr!==F.appr) return false;
    if(q){
      const hay = [o.name,o.reg,o.addr,o.dir,o.phone,o.cat,o.own,o.lic].join(" ").toLowerCase();
      if(!hay.includes(q)) return false;
    }
    return true;
  });
  list.sort((a,b)=>{
    let x = a[F.sort] ?? "", y = b[F.sort] ?? "";
    if(F.sort==="khoroo" || F.sort==="staff" || F.sort==="staffN"){ return ((Number(x)||0) - (Number(y)||0)) * F.dir; }
    return String(x).localeCompare(String(y), "mn") * F.dir;
  });
  return list;
}

function paintTable(){
  const list = filtered();
  $("#listTitle").textContent = `Бүртгэлийн жагсаалт — ${list.length} нэгж`;
  paintMap();
  if(!list.length){
    const anyFilter = F.q || F.cat || F.own || F.khoroo || F.status || F.appr;
    $("#tbl").innerHTML = DB.orgs.length
      ? `<div class="empty">${anyFilter ? "Шүүлтэд тохирох бүртгэл олдсонгүй. Шүүлтээ өөрчилж үзнэ үү." : "Бүртгэл алга байна."}</div>`
      : `<div class="empty">Одоогоор бүртгэгдсэн аж ахуйн нэгж алга байна.<br>“Байгууллага нэмэх” товчоор шууд бүртгэх, эсвэл байгууллага өөрөө “Бүртгүүлэх” хэсгээр хүсэлт илгээх боломжтой.</div>`;
    return;
  }
  const th = (k,t)=>`<th class="sortable" data-k="${k}">${t}${F.sort===k?(F.dir>0?" ↑":" ↓"):""}</th>`;
  $("#tbl").innerHTML = `
    <table>
      <thead><tr>
        ${th("name","Байгууллага")}${th("cat","Чиглэл")}${th("own","Өмч")}${th("khoroo","Хороо")}
        <th>Хаяг</th>${th("staffN","Ажилтан")}<th>Камер<div class="reg">гадна/дотор</div></th><th>Зөвшөөрөл</th>${th("status","Төлөв")}<th>Бүртгэл</th><th>Холбоо барих</th><th></th>
      </tr></thead>
      <tbody>${list.map(o=>`
        <tr>
          <td><div class="name">${esc(o.name)}</div><div class="reg">№${esc(o.reg)}</div></td>
          <td>${esc(o.cat)}</td>
          <td>${esc(o.own)}</td>
          <td class="num">${esc(o.khoroo)}</td>
          <td>${esc(o.addr)||'<span class="note">—</span>'}${o.lat&&o.lng?`<div class="reg"><a href="https://www.google.com/maps?q=${encodeURIComponent(o.lat+","+o.lng)}" target="_blank" rel="noopener">${esc(o.lat)}, ${esc(o.lng)}</a></div>`:""}</td>
          <td class="num">${o.staffN||0}<div class="reg">зарласан ${esc(o.staff)||"—"}</div></td>
          <td class="num">${(Number(o.camOut)||0)+(Number(o.camIn)||0)}<div class="reg">${esc(o.camOut||0)} / ${esc(o.camIn||0)}</div></td>
          <td>${licPill(o)}</td>
          <td>${statusPill(o.status)}</td>
          <td>${apprPill(o)}</td>
          <td>${esc(o.dir)}<div class="reg">${esc(o.phone)}</div></td>
          <td><button class="btn ghost sm" data-open="${o.id}">Дэлгэрэнгүй</button></td>
        </tr>`).join("")}
      </tbody>
    </table>`;
  $("#tbl").querySelectorAll("th.sortable").forEach(h=>h.onclick=()=>{
    const k = h.dataset.k; F.dir = (F.sort===k) ? -F.dir : 1; F.sort = k; paintTable();
  });
  $("#tbl").querySelectorAll("[data-open]").forEach(b=>b.onclick=()=>detail(b.dataset.open));
}

function paintKhoroo(){
  const host = $("#khList"), tag = $("#khCount"); if(!host) return;
  if(!KH){ tag.textContent = ""; host.innerHTML = `<p class="note">Хороо сонгоход тухайн хороонд бүртгэлтэй байгууллагууд энд жагсана.</p>`; return; }
  const n = parseInt(KH);
  const list = DB.orgs.filter(o=>Number(o.khoroo)===n).sort((a,b)=>String(a.name).localeCompare(String(b.name),"mn"));
  tag.textContent = `${n}-р хороо — нийт ${list.length} нэгж (зөвшөөрөгдсөн ${list.filter(o=>o.appr==="ok").length})`;
  host.innerHTML = list.length ? `
    <table>
      <thead><tr><th>Байгууллага</th><th>Чиглэл</th><th>Өмч</th><th>Хаяг</th><th>Зөвшөөрөл</th><th>Төлөв</th><th>Бүртгэл</th><th></th></tr></thead>
      <tbody>${list.map(o=>`
        <tr>
          <td><div class="name">${esc(o.name)}</div><div class="reg">№${esc(o.reg)}</div></td>
          <td>${esc(o.cat)}</td>
          <td>${esc(o.own)}</td>
          <td>${esc(o.addr)||'<span class="note">—</span>'}</td>
          <td>${licPill(o)}</td>
          <td>${statusPill(o.status)}</td>
          <td>${apprPill(o)}</td>
          <td><button class="btn ghost sm" data-open2="${o.id}">Дэлгэрэнгүй</button></td>
        </tr>`).join("")}</tbody>
    </table>` : `<div class="empty">${n}-р хороонд бүртгэлтэй нэгж алга байна.</div>`;
  host.querySelectorAll("[data-open2]").forEach(b=>b.onclick=()=>detail(b.dataset.open2));
}

function paintBars(){
  const draw = (host, pairs, onPick) => {
    if(!host) return;
    const max = Math.max(1, ...pairs.map(p=>p[1]));
    host.innerHTML = pairs.length ? pairs.map(([k,v])=>`
      <div class="barrow"><span class="${onPick?"clickable":""}" data-key="${esc(k)}">${esc(k)}</span>
        <span class="bartrack"><span class="barfill" style="width:${Math.round(v/max*100)}%"></span></span>
        <i class="num">${v}</i></div>`).join("") : `<p class="note">Мэдээлэл алга.</p>`;
    if(onPick) host.querySelectorAll("[data-key]").forEach(el=>el.onclick=()=>onPick(el.dataset.key));
  };
  const count = key => {
    const m = new Map();
    okOrgs().forEach(o=>m.set(o[key], (m.get(o[key])||0)+1));
    return [...m.entries()].sort((a,b)=>b[1]-a[1]);
  };
  draw($("#byCat"), count("cat"), v => { F.cat = v; renderAdmin(); window.scrollTo({top:0,behavior:"smooth"}); });
  draw($("#byOwn"), count("own"), v => { F.own = v; renderAdmin(); window.scrollTo({top:0,behavior:"smooth"}); });
  draw($("#byKh"),  count("khoroo").map(([k,v])=>[k+"-р хороо", v]).sort((a,b)=>b[1]-a[1]),
       v => { KH = v; fillSelect($("#khSel"), ["— сонгох —", ...KHOROOS.map(k=>k+"-р хороо")], KH); paintKhoroo(); $("#khList").scrollIntoView({behavior:"smooth", block:"center"}); });
}

function detail(id){
  const o = DB.orgs.find(x=>x.id===id); if(!o) return;
  const nlist = (o.notices||[]).slice(0,6);
  const body = `
    <div id="admMedia"><p class="note">Зураг, баримт ачаалж байна…</p></div>
    ${kvTable(o)}
    <h3 style="font-size:14px;margin:18px 0 9px">Ажилчдын бүртгэл</h3>
    <div class="count-tag" id="staffMeta"></div>
    <div class="tblwrap" id="staffBox"><p class="note">Ачаалж байна…</p></div>
    ${o.appr==="rejected" && o.apprNote ? `<div class="msg err" style="margin-top:14px">Татгалзсан шалтгаан: ${esc(o.apprNote)}</div>` : ""}
    <h3 style="font-size:14px;margin:18px 0 9px">Илгээсэн мэдэгдэл</h3>
    ${nlist.length ? nlist.map(n=>`<div class="notice ${esc(n.kind)}"><div><div>${esc(n.text)}</div>${noticeImgs(n)}
      <div class="when">${esc(n.date)} · ${n.read?"уншсан":"уншаагүй"}</div></div></div>`).join("")
      : `<p class="note">Мэдэгдэл илгээгээгүй байна.</p>`}
  `;
  const acts = [
    {label:"Хаах", cls:"ghost", act:closeModal},
    {label:"Устгах", cls:"danger", act:(btn)=>{
      if(btn.dataset.armed){
        DB.orgs = DB.orgs.filter(x=>x.id!==id);
        DBX.delete(MKEY(id), true).catch(()=>{});
        DBX.delete(SKEY(id), true).catch(()=>{});
        delete mediaCache[id]; delete staffCache[id];
        saveDB().then(()=>{ closeModal(); render(); toast("Бүртгэлийг устгалаа."); });
      } else { btn.dataset.armed="1"; btn.textContent="Устгахыг баталгаажуулах"; }
    }},
    {label:"Нууц үг сэргээх", cls:"ghost", act:async ()=>{
      o.pw = await sha("1234");
      pushNotice(o, "pw:"+uid(), "info", "Админ таны нууц үгийг 1234 болгон сэргээлээ. Нэвтэрсний дараа шинэ нууц үг тохируулна уу.");
      await saveDB(); closeModal(); render(); toast("Нууц үгийг 1234 болголоо.");
    }},
    {label:"Анкет татах", cls:"ghost", act:()=>downloadAnket(o)},
    {label:"Мэдэгдэл илгээх", cls:"ghost", act:()=>{ closeModal(); noticeForm(o); }},
    {label:"Засах", cls:"", act:()=>{ closeModal(); orgForm(o); }}
  ];
  if(o.appr==="pending"){
    acts.splice(1, 0,
      {label:"Татгалзах", cls:"danger", act:()=>{ closeModal(); rejectForm(o.id); }},
      {label:"Зөвшөөрөх", cls:"", act:()=>{ closeModal(); approveOrg(o.id); }});
  }
  openModal(o.name, body, acts);
  paintAdminMedia(o);
  paintStaff(o, false);
}

async function paintAdminMedia(o){
  const m = await loadMedia(o.id);
  const host = $("#admMedia"); if(!host) return;
  host.innerHTML = `
    <div style="font-size:13px;font-weight:600;margin-bottom:7px">Тусгай зөвшөөрлийн баримт (${m.lics.length})</div>
    ${m.lics.length ? `<div class="gallery" style="margin-bottom:14px">${m.lics.map((L,i)=>`
        <div class="shot">
          ${L.data.startsWith("data:image") ? `<img src="${L.data}" alt="Тусгай зөвшөөрөл ${i+1}">`
            : `<span class="photo34 ph" style="width:100%;aspect-ratio:4/3;display:flex;align-items:center;justify-content:center">📄 PDF</span>`}
          <div class="reg" style="padding:6px 2px 0">${esc(L.name||("Баримт "+(i+1)))} · ${esc(L.at||"")}</div>
          <button class="btn ghost sm" data-algt="${i}" style="margin-top:4px">Татаж авах</button>
        </div>`).join("")}</div>`
      : `<p class="note">Тусгай зөвшөөрлийн баримт байршуулаагүй.</p>`}
    <div style="font-size:13px;font-weight:600;margin-bottom:7px">Байгууллагын зураг (${m.photos.length})</div>
    ${m.photos.length ? `<div class="gallery" style="margin-bottom:14px">${m.photos.map((p,i)=>`<div class="shot"><img src="${p}" alt="Зураг ${i+1}"></div>`).join("")}</div>`
      : `<p class="note">Байгууллагын зураг оруулаагүй.</p>`}`;
  host.querySelectorAll("[data-algt]").forEach(b=>b.onclick = () => {
    const L = m.lics[+b.dataset.algt]; if(L) openData(L.data, L.name);
  });
}

function noticeForm(o){
  let imgs = [];   // хавсаргасан зургууд
  openModal(`Мэдэгдэл илгээх — ${o.name}`, `
    <div class="field"><label>Төрөл</label><select id="n_kind">
      <option value="info">Мэдээлэл</option><option value="warn">Анхааруулга</option><option value="bad">Шаардлага</option>
    </select></div>
    <div class="field"><label>Мэдэгдлийн агуулга</label><textarea id="n_text" rows="4" placeholder="Жишээ: Тусгай зөвшөөрлийн хуулбарыг 10 хоногийн дотор системд байршуулна уу."></textarea></div>
    <div class="field"><label>Хавсаргах зураг (заавал биш)</label>
      <div class="gallery" id="n_imgs"></div>
      <div style="margin-top:9px"><label class="upl" style="padding:6px 12px;font-size:12.5px">Зураг нэмэх<input type="file" accept="image/*" multiple id="n_up"></label></div>
    </div>
    <p class="note">Мэдэгдэл болон хавсаргасан зураг тухайн байгууллагын хуудсанд шууд харагдана. Хамгийн ихдээ 3 зураг.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Илгээх", cls:"", act:async ()=>{
      const t = $("#n_text").value.trim();
      if(!t) return toast("Агуулгаа бичнэ үү.");
      pushNotice(o, "adm:"+uid(), $("#n_kind").value, t, imgs);
      await saveDB(); closeModal(); render(); toast("Мэдэгдлийг илгээлээ.");
    }}
  ]);
  const paintImgs = () => {
    $("#n_imgs").innerHTML = imgs.length
      ? imgs.map((p,i)=>`<div class="shot"><img src="${p}" alt="Хавсралт ${i+1}"><button data-ni="${i}">Устгах</button></div>`).join("")
      : `<p class="note" style="margin:0">Зураг хавсаргаагүй.</p>`;
    $("#n_imgs").querySelectorAll("[data-ni]").forEach(b=>b.onclick=()=>{ imgs.splice(+b.dataset.ni,1); paintImgs(); });
  };
  $("#n_up").onchange = async e => {
    const files = [...e.target.files];
    if(imgs.length + files.length > 3) return toast("Хамгийн ихдээ 3 зураг хавсаргана.");
    for(const f of files){ if(f.type.startsWith("image/")) imgs.push(await shrinkImage(f, 1000, .7)); }
    paintImgs(); e.target.value = "";
  };
  paintImgs();
}

/* ---------- Ажилчид ---------- */
async function paintStaff(o, editable){
  const host = $("#staffBox"); if(!host) return;
  const list = await loadStaff(o.id);
  const active = list.filter(s=>s.status!=="Чөлөөлөгдсөн").length;
  const noReg  = list.filter(s=>!s.reg).length;
  const meta = $("#staffMeta");
  if(meta) meta.textContent = `Нийт ${list.length} ажилтан · ажиллаж байгаа ${active}` +
    (noReg ? ` · регистр оруулаагүй ${noReg}` : "") +
    (o.staff ? ` · зарласан орон тоо ${o.staff}` : "");
  if(!list.length){
    host.innerHTML = `<div class="empty">Ажилтан бүртгээгүй байна.${editable?" “Ажилтан нэмэх” товчоор эхлүүлнэ үү.":""}</div>`;
    return;
  }
  host.innerHTML = `
    <table>
      <thead><tr><th>Овог нэр</th><th>Регистрийн дугаар</th><th>Албан тушаал</th><th>Утас</th><th>Ажилд орсон</th><th>Гэрийн хаяг</th><th>Төлөв</th>${editable?"<th></th>":""}</tr></thead>
      <tbody>${list.map((st,i)=>`
        <tr>
          <td><div class="staffcell">
            ${st.photo ? `<img class="photo34" src="${st.photo}" alt="${esc(st.name)}">` : `<span class="photo34 ph">зураг<br>алга</span>`}
            <span><span class="name">${esc(st.name)}</span></span>
          </div></td>
          <td>${st.reg ? esc(st.reg) : '<span class="pill warn">оруулаагүй</span>'}</td>
          <td>${esc(st.pos)}</td>
          <td>${esc(st.phone)||'<span class="note">—</span>'}</td>
          <td>${esc(st.since)||'<span class="note">—</span>'}</td>
          <td>${esc(st.addr)||'<span class="note">—</span>'}</td>
          <td><span class="pill ${st.status==="Чөлөөлөгдсөн"?"neutral":"ok"}">${esc(st.status)}</span></td>
          ${editable?`<td><button class="btn ghost sm" data-st="${i}">Засах</button></td>`:""}
        </tr>`).join("")}
      </tbody>
    </table>`;
  if(editable) host.querySelectorAll("[data-st]").forEach(b=>b.onclick=()=>staffForm(o, +b.dataset.st));
}

function staffForm(o, idx){
  const list = staffCache[o.id] || [];
  const isNew = idx===null || idx===undefined;
  const v = isNew ? { name:"",pos:POSITIONS[0],reg:"",phone:"",since:"",addr:"",status:STAFF_STATUS[0],note:"",photo:"" } : list[idx];
  let photo = v.photo || "";
  openModal(isNew?"Ажилтан нэмэх":"Ажилтны мэдээлэл", `
    <div class="filebox" id="s_photoWrap" style="margin-bottom:16px"></div>
    <div class="two">
      <div class="field"><label>Овог, нэр</label><input id="s_name" value="${esc(v.name)}"></div>
      <div class="field"><label>Албан тушаал</label><select id="s_pos"></select></div>
    </div>
    <div class="two">
      <div class="field"><label>Регистрийн дугаар</label><input id="s_reg" value="${esc(v.reg)}" placeholder="УБ12345678"></div>
      <div class="field"><label>Утас</label><input id="s_phone" value="${esc(v.phone)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>Ажилд орсон огноо</label><input id="s_since" type="date" value="${esc(v.since)}"></div>
      <div class="field"><label>Төлөв</label><select id="s_status"></select></div>
    </div>
    <div class="field"><label>Гэрийн хаяг</label><input id="s_addr" value="${esc(v.addr||"")}" placeholder="дүүрэг, хороо, хороолол, байр, тоот"></div>
    <div class="field"><label>Тэмдэглэл</label><textarea id="s_note" rows="2">${esc(v.note)}</textarea></div>
    <p class="note">Регистрийн дугаар болон гэрийн хаяг нь хүний хувийн мэдээлэл тул зөвхөн албан ёсны бүртгэлийн зориулалтаар ашиглана.</p>`,
    [
      {label:"Болих", cls:"ghost", act:closeModal},
      ...(isNew ? [] : [{label:"Устгах", cls:"danger", act:async (btn)=>{
        if(!btn.dataset.armed){ btn.dataset.armed="1"; btn.textContent="Устгахыг баталгаажуулах"; return; }
        list.splice(idx,1); await saveStaff(o.id, list, o); closeModal(); paintStaff(o, true); toast("Ажилтныг устгалаа.");
      }}]),
      {label:"Хадгалах", cls:"", act:async ()=>{
        const name = $("#s_name").value.trim();
        if(!name) return toast("Овог нэрийг бөглөнө үү.");
        const rd = $("#s_reg").value.trim();
        if(!rd) return toast("Регистрийн дугаарыг бөглөнө үү.");
        const data = {
          name, pos:$("#s_pos").value, reg:rd, phone:$("#s_phone").value.trim(),
          since:$("#s_since").value, addr:$("#s_addr").value.trim(),
          status:$("#s_status").value, note:$("#s_note").value.trim(), photo
        };
        if(isNew) list.push({ id:uid(), ...data, created:today() });
        else Object.assign(list[idx], data);
        await saveStaff(o.id, list, o);
        closeModal(); paintStaff(o, true); toast(isNew?"Ажилтан нэмэгдлээ.":"Мэдээллийг шинэчиллээ.");
      }}
    ]);
  fillSelect($("#s_pos"), POSITIONS, v.pos);
  fillSelect($("#s_status"), STAFF_STATUS, v.status);

  const paintPhoto = () => {
    $("#s_photoWrap").innerHTML = `
      ${photo ? `<img class="photo34 big" src="${photo}" alt="Цээж зураг">` : `<span class="photo34 big ph">3×4<br>цээж зураг</span>`}
      <div>
        <div style="font-size:13px;font-weight:600">Цээж зураг (3×4)</div>
        <div class="note" style="margin-bottom:8px">Ямар ч хэмжээтэй зураг оруулахад 3:4 харьцаагаар голлон тайрч, 300×400 болгож хадгална.</div>
        <div style="display:flex;gap:9px;flex-wrap:wrap">
          <label class="upl" style="padding:6px 12px;font-size:12.5px">${photo?"Зураг солих":"Зураг сонгох"}<input type="file" accept="image/*" id="s_photoUp"></label>
          ${photo?`<button class="btn ghost sm" id="s_photoDel">Зураг устгах</button>`:""}
        </div>
      </div>`;
    $("#s_photoUp").onchange = async e => {
      const f = e.target.files[0]; if(!f || !f.type.startsWith("image/")) return;
      photo = await cropPhoto34(f); paintPhoto(); toast("Зураг бэлэн боллоо. Хадгалахаа мартуузай.");
    };
    if($("#s_photoDel")) $("#s_photoDel").onclick = () => { photo = ""; paintPhoto(); };
  };
  paintPhoto();
}

function exportStaffCSV(o, list){
  if(!list.length) return toast("Бүртгэсэн ажилтан алга.");
  const cols = [["Овог нэр","name"],["Регистрийн дугаар","reg"],["Албан тушаал","pos"],["Утас","phone"],
                ["Ажилд орсон","since"],["Гэрийн хаяг","addr"],["Төлөв","status"],["Тэмдэглэл","note"]];
  const q = s => `"${String(s ?? "").replace(/"/g,'""')}"`;
  const head = [q("Байгууллага"), ...cols.map(c=>q(c[0]))].join(",");
  const rows = list.map(st=>[q(o.name), ...cols.map(c=>q(st[c[1]]))].join(","));
  downloadBlob("\uFEFF" + [head, ...rows].join("\r\n"), "text/csv;charset=utf-8;", `ajilchid_${o.reg}.csv`);
  toast(`${list.length} ажилтан татагдлаа.`);
}

/* ---------- Форм ---------- */
function orgForm(o){
  const isNew = !o;
  const isAdmin = ME.role==="admin";
  const v = o || { name:"",reg:"",cat:CATS[0],own:OWNERS[0],district:"Хан-Уул",khoroo:1,addr:"",lat:"",lng:"",area:"",staff:"",camOut:"",camIn:"",hours:"",lic:"",licEnd:"",dir:"",phone:"",mail:"",since:"",status:"Идэвхтэй",note:"" };
  const body = `
    <div class="two">
      <div class="field"><label>Байгууллагын нэр</label><input id="e_name" value="${esc(v.name)}"></div>
      <div class="field"><label>Байгууллагын регистр</label><input id="e_reg" value="${esc(v.reg)}" ${isAdmin?"":"disabled"}></div>
    </div>
    <div class="two">
      <div class="field"><label>Үйл ажиллагааны чиглэл</label><select id="e_cat"></select></div>
      <div class="field"><label>Өмчийн хэлбэр</label><select id="e_own"></select></div>
    </div>
    <div class="two">
      <div class="field"><label>Хороо</label><select id="e_kh"></select></div>
      <div class="field"><label>Ажиллах цагийн хуваарь</label><input id="e_hours" placeholder="09:00–21:00" value="${esc(v.hours)}"></div>
    </div>
    <div class="field"><label>Дэлгэрэнгүй хаяг</label><input id="e_addr" value="${esc(v.addr)}"></div>
    <div class="two">
      <div class="field"><label>Өргөрөг (latitude)</label><input id="e_lat" value="${esc(v.lat||"")}" placeholder="47.906412"></div>
      <div class="field"><label>Уртраг (longitude)</label><input id="e_lng" value="${esc(v.lng||"")}" placeholder="106.907318"></div>
    </div>
    <p class="note" style="margin:-6px 0 12px">Google Maps дээр цэгээ дараад гарч ирэх хоёр тоог (жишээ: 47.906412, 106.907318) эхнийхийг өргөрөгт, хоёр дахийг уртрагт оруулна.</p>
    <div class="two">
      <div class="field"><label>Талбай, м²</label><input id="e_area" type="number" min="0" value="${esc(v.area)}"></div>
      <div class="field"><label>Ажиллагсдын тоо</label><input id="e_staff" type="number" min="0" value="${esc(v.staff)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>Гадна камерын тоо</label><input id="e_camOut" type="number" min="0" value="${esc(v.camOut)}"></div>
      <div class="field"><label>Дотор камерын тоо</label><input id="e_camIn" type="number" min="0" value="${esc(v.camIn)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>Тусгай зөвшөөрлийн дугаар</label><input id="e_lic" value="${esc(v.lic)}"></div>
      <div class="field"><label>Зөвшөөрөл дуусах огноо</label><input id="e_licEnd" type="date" value="${esc(v.licEnd)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>Захирал / эзэмшигч</label><input id="e_dir" value="${esc(v.dir)}"></div>
      <div class="field"><label>Утас</label><input id="e_phone" value="${esc(v.phone)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>И-мэйл</label><input id="e_mail" value="${esc(v.mail)}"></div>
      <div class="field"><label>Үйл ажиллагаа эхэлсэн огноо</label><input id="e_since" type="date" value="${esc(v.since)}"></div>
    </div>
    <div class="two">
      <div class="field"><label>Төлөв</label><select id="e_status" ${isAdmin?"":"disabled"}></select></div>
      ${isNew?`<div class="field"><label>Нууц үг (байгууллага нэвтрэхэд)</label><input id="e_pw" value="1234"></div>`:"<div></div>"}
    </div>
    <div class="field"><label>Тэмдэглэл</label><textarea id="e_note" rows="2">${esc(v.note)}</textarea></div>
    ${isAdmin?"":`<p class="note">Байгууллагын регистр, төлөвийг зөвхөн 2-р хэлтсийн админ өөрчилнө.</p>`}
  `;
  openModal(isNew?"Шинэ байгууллага бүртгэх":"Мэдээлэл засах", body, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Хадгалах", cls:"", act:async ()=>{
      const name = $("#e_name").value.trim();
      const reg  = isAdmin ? $("#e_reg").value.trim() : v.reg;
      if(!name || !reg) return toast("Нэр болон байгууллагын регистрийг бөглөнө үү.");
      if(DB.orgs.some(x=>x.reg===reg && x.id!==(o && o.id))) return toast("Энэ регистрийн дугаартай нэгж бүртгэлтэй байна.");
      const lat = $("#e_lat").value.trim(), lng = $("#e_lng").value.trim();
      if(lat && !/^-?\d{1,3}(\.\d+)?$/.test(lat)) return toast("Өргөрөг буруу байна. Жишээ: 47.906412");
      if(lng && !/^-?\d{1,3}(\.\d+)?$/.test(lng)) return toast("Уртраг буруу байна. Жишээ: 106.907318");
      const data = {
        name, reg, cat:$("#e_cat").value, own:$("#e_own").value, district:"Хан-Уул",
        khoroo:Number($("#e_kh").value), addr:$("#e_addr").value.trim(), lat, lng,
        area:$("#e_area").value, staff:$("#e_staff").value,
        camOut:$("#e_camOut").value, camIn:$("#e_camIn").value, hours:$("#e_hours").value.trim(),
        since:$("#e_since").value, lic:$("#e_lic").value.trim(), licEnd:$("#e_licEnd").value,
        dir:$("#e_dir").value.trim(), phone:$("#e_phone").value.trim(), mail:$("#e_mail").value.trim(),
        status:isAdmin?$("#e_status").value:v.status, note:$("#e_note").value.trim()
      };
      if(isNew){
        DB.orgs.push({ id:uid(), ...data, appr:"ok", apprAt:today(), apprNote:"", pw:await sha($("#e_pw").value||"1234"), created:today(), notices:[] });
      } else {
        Object.assign(o, data);
      }
      await saveDB(); await ensureNotices(); closeModal(); render();
      toast(isNew?"Бүртгэл нэмэгдлээ.":"Мэдээллийг шинэчиллээ.");
    }}
  ]);
  fillSelect($("#e_cat"), CATS, v.cat);
  fillSelect($("#e_own"), OWNERS, v.own);
  fillSelect($("#e_kh"), KHOROOS.map(String), String(v.khoroo));
  fillSelect($("#e_status"), STATUSES, v.status);
}

function pwForm(o){
  openModal("Нууц үг солих", `
    <div class="field"><label>Одоогийн нууц үг</label><input id="p_old" type="password"></div>
    <div class="field"><label>Шинэ нууц үг</label><input id="p_new" type="password"></div>
    <div class="field"><label>Шинэ нууц үг давтах</label><input id="p_new2" type="password"></div>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Нууц үг солих", cls:"", act:async ()=>{
      if(!await pwVerify(o.pw, $("#p_old").value)) return toast("Одоогийн нууц үг буруу байна.");
      if($("#p_new").value.length<4) return toast("Шинэ нууц үг дор хаяж 4 тэмдэгт байна.");
      if($("#p_new").value!==$("#p_new2").value) return toast("Шинэ нууц үг таарахгүй байна.");
      o.pw = await sha($("#p_new").value); await saveDB(); closeModal(); toast("Нууц үг солигдлоо.");
    }}
  ]);
}

/* Нэвтэрсэн админ өөрийн нууц үгээ солих */
function adminPwForm(){
  const me = meAdmin();
  if(!me) return toast("Эрхийн мэдээлэл олдсонгүй.");
  openModal(`Нууц үг солих — ${me.name}`, `
    <div class="field"><label>Одоогийн нууц үг</label><input id="a_old" type="password"></div>
    <div class="field"><label>Шинэ нууц үг</label><input id="a_new" type="password"></div>
    <div class="field"><label>Шинэ нууц үг давтах</label><input id="a_new2" type="password"></div>
    <p class="note">Нэвтрэх нэр: <b>${esc(me.user)}</b>. Шинэ нууц үг зөвхөн хураангуй хэлбэрээр хадгалагдана — мартвал өөр админ сэргээж өгнө.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Солих", cls:"", act:async ()=>{
      if(await sha($("#a_old").value) !== me.pw) return toast("Одоогийн нууц үг буруу байна.");
      if($("#a_new").value.length < 6) return toast("Шинэ нууц үг дор хаяж 6 тэмдэгт байна.");
      if($("#a_new").value !== $("#a_new2").value) return toast("Шинэ нууц үг таарахгүй байна.");
      me.pw = await sha($("#a_new").value); me.changed = today();
      await saveDB(); closeModal(); render(); toast("Нууц үг солигдлоо.");
    }}
  ]);
}

/* ---------- Админы эрхийн жагсаалт ---------- */
function paintAdmins(){
  const host = $("#admBox"); if(!host) return;
  const list = DB.admins || [];
  host.innerHTML = `
    <table>
      <thead><tr><th>Нэр</th><th>Албан тушаал, цол</th><th>Нэвтрэх нэр</th><th>Нууц үг сүүлд солисон</th><th></th></tr></thead>
      <tbody>${list.map(a=>`
        <tr>
          <td><div class="name">${esc(a.name)}</div>${a.user===ME.user?'<div class="reg">та энэ эрхээр нэвтэрсэн</div>':""}</td>
          <td>${esc(a.rank||"")}</td>
          <td><code>${esc(a.user)}</code></td>
          <td>${a.changed ? esc(a.changed) : '<span class="pill warn">анхны нууц үг</span>'}</td>
          <td style="white-space:nowrap">
            <button class="btn ghost sm" data-areset="${esc(a.user)}">Нууц үг сэргээх</button>
            ${a.user===ME.user || list.length<=1 ? "" : `<button class="btn ghost sm" data-adel="${esc(a.user)}">Устгах</button>`}
          </td>
        </tr>`).join("")}
      </tbody>
    </table>`;
  host.querySelectorAll("[data-areset]").forEach(b=>b.onclick=()=>adminReset(b.dataset.areset));
  host.querySelectorAll("[data-adel]").forEach(b=>b.onclick=()=>adminDelete(b.dataset.adel));
}

function adminReset(user){
  const a = (DB.admins||[]).find(x=>x.user===user); if(!a) return;
  openModal(`Нууц үг сэргээх — ${a.name}`, `
    <p>Энэ эрхийн нууц үгийг түр нууц үг болгон сэргээх үү?</p>
    <dl class="kv">
      <dt>Нэвтрэх нэр</dt><dd><b>${esc(a.user)}</b></dd>
      <dt>Шинэ түр нууц үг</dt><dd><b>${esc(ADMIN_RESET_PW)}</b></dd>
    </dl>
    <p class="note">Эзэмшигч нь нэвтэрсний дараа «Миний нууц үг солих» хэсгээр заавал өөрчилнө.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Сэргээх", cls:"danger", act:async ()=>{
      a.pw = await sha(ADMIN_RESET_PW); a.changed = "";
      await saveDB(); closeModal(); render(); toast(`${a.name}-ийн нууц үгийг сэргээлээ.`);
    }}
  ]);
}

function adminDelete(user){
  const a = (DB.admins||[]).find(x=>x.user===user); if(!a) return;
  openModal(`Эрх устгах — ${a.name}`, `
    <div class="msg err">Энэ админ эрх бүрмөсөн устах бөгөөд дахин нэвтрэх боломжгүй болно.</div>
    <p class="note">Бүртгэлийн өгөгдөлд өөрчлөлт орохгүй.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Устгах", cls:"danger", act:async (btn)=>{
      if(!btn.dataset.armed){ btn.dataset.armed="1"; btn.textContent="Устгахыг баталгаажуулах"; return; }
      DB.admins = DB.admins.filter(x=>x.user!==user);
      await saveDB(); closeModal(); render(); toast("Эрхийг устгалаа.");
    }}
  ]);
}

function adminAddForm(){
  openModal("Админ эрх нэмэх", `
    <div class="two">
      <div class="field"><label>Нэр</label><input id="na_name" placeholder="Ж.Жаргал"></div>
      <div class="field"><label>Нэвтрэх нэр (латинаар)</label><input id="na_user" placeholder="jargal"></div>
    </div>
    <div class="field"><label>Албан тушаал, цол</label><input id="na_rank" placeholder="Хэсгийн байцаагч, цагдаагийн ахлах дэслэгч"></div>
    <div class="two">
      <div class="field"><label>Нууц үг</label><input id="na_pw" type="password"></div>
      <div class="field"><label>Нууц үг давтах</label><input id="na_pw2" type="password"></div>
    </div>
    <p class="note">Нэвтрэх нэр зөвхөн латин үсэг, тоо, цэгээс бүрдэнэ. Нууц үг дор хаяж 6 тэмдэгт.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Нэмэх", cls:"", act:async ()=>{
      const name = $("#na_name").value.trim();
      const user = $("#na_user").value.trim().toLowerCase();
      if(!name) return toast("Нэрийг бөглөнө үү.");
      if(!/^[a-z0-9.]{3,20}$/.test(user)) return toast("Нэвтрэх нэр 3–20 тэмдэгт, латин үсэг/тоо/цэг байна.");
      if((DB.admins||[]).some(x=>x.user===user)) return toast("Энэ нэвтрэх нэр аль хэдийн бүртгэлтэй байна.");
      if($("#na_pw").value.length < 6) return toast("Нууц үг дор хаяж 6 тэмдэгт байна.");
      if($("#na_pw").value !== $("#na_pw2").value) return toast("Нууц үг таарахгүй байна.");
      DB.admins.push({ user, name, rank:$("#na_rank").value.trim(),
                       pw:await sha($("#na_pw").value), created:today(), changed:today() });
      await saveDB(); closeModal(); render(); toast("Админ эрх нэмэгдлээ.");
    }}
  ]);
}

/* ---------- Модал ---------- */
function openModal(title, body, buttons){
  $("#modalHost").innerHTML = `
    <div class="modal-bg"><div class="modal">
      <h3>${esc(title)}<button class="x" id="mx">×</button></h3>
      <div class="body">${body}</div>
      <div class="foot">${buttons.map((b,i)=>`<button class="btn ${b.cls}" data-i="${i}">${esc(b.label)}</button>`).join("")}</div>
    </div></div>`;
  attachPwToggles($("#modalHost"));
  $("#mx").onclick = closeModal;
  $("#modalHost").querySelector(".modal-bg").onclick = e => { if(e.target.classList.contains("modal-bg")) closeModal(); };
  $("#modalHost").querySelectorAll(".foot .btn").forEach(btn=>btn.onclick=()=>buttons[+btn.dataset.i].act(btn));
}
function closeModal(){ $("#modalHost").innerHTML=""; }
document.addEventListener("keydown", e => { if(e.key==="Escape") closeModal(); });

/* ---------- CSV ---------- */
function exportCSV(list, filename){
  const cols = [
    ["Байгууллагын нэр","name"],["Байгууллагын регистр","reg"],["Үйл ажиллагааны чиглэл","cat"],["Өмчийн хэлбэр","own"],
    ["Дүүрэг","district"],["Хороо","khoroo"],["Хаяг","addr"],["Өргөрөг","lat"],["Уртраг","lng"],["Талбай (м²)","area"],["Ажиллагсдын тоо (зарласан)","staff"],["Бүртгэсэн ажилтан","staffN"],
    ["Ажиллах цаг","hours"],["Гадна камер","camOut"],["Дотор камер","camIn"],["Тусгай зөвшөөрөл","lic"],["Зөвшөөрөл дуусах","licEnd"],["Захирал","dir"],
    ["Утас","phone"],["И-мэйл","mail"],["Эхэлсэн огноо","since"],["Төлөв","status"],["Тэмдэглэл","note"],["Бүртгүүлсэн огноо","created"]
  ];
  const q = s => `"${String(s ?? "").replace(/"/g,'""')}"`;
  const head = cols.map(c=>q(c[0])).concat(q("Бүртгэлийн төлөв")).join(",");
  const rows = list.map(o=>cols.map(c=>q(o[c[1]])).concat(q(APPR[o.appr]||"")).join(","));
  downloadBlob("\uFEFF" + [head, ...rows].join("\r\n"), "text/csv;charset=utf-8;", filename);
  toast(`${list.length} мөр татагдлаа.`);
}

/* ============================================================
   НӨӨЦЛӨЛТ · ИМПОРТ · ГАЗРЫН ЗУРАГ
   ============================================================ */

/* ---------- Хадгалах зайн хэмжүүр ---------- */
function storageUsed(){
  let n = 0;
  try{ for(let i=0;i<localStorage.length;i++){ const k=localStorage.key(i); n += (localStorage.getItem(k)||"").length + k.length; } }catch(e){}
  return n*2;   // UTF-16 тэмдэгт тус бүр ойролцоогоор 2 байт
}
function paintStorage(){
  const el = $("#stoMeter"); if(!el) return;
  const mb = storageUsed()/1048576;
  const warn = mb>3.5 ? `<span class="pill bad">Дүүрэхэд ойрхон — яаралтай нөөцөлнө үү</span>`
             : mb>2.5 ? `<span class="pill warn">Анхаарна уу</span>` : `<span class="pill ok">Хэвийн</span>`;
  el.innerHTML = `Эзэлж буй хэмжээ <b>${mb.toFixed(2)} МБ</b> / браузерын багтаамж ойролцоогоор 5 МБ · `
               + `${DB.orgs.length} байгууллага &nbsp; ${warn}`;
}

/* ---------- Бүх өгөгдлийг нөөцлөх ---------- */
async function backupAll(){
  toast("Нөөц бэлтгэж байна…");
  const pack = { app:"khanuul-registry", v:1, at:new Date().toISOString(), db:DB, media:{}, staff:{} };
  for(const o of DB.orgs){
    pack.media[o.id] = await loadMedia(o.id);
    pack.staff[o.id] = await loadStaff(o.id);
  }
  downloadBlob(JSON.stringify(pack), "application/json;charset=utf-8", `khanuul_nooc_${today()}.json`);
  toast(`${DB.orgs.length} байгууллагын өгөгдөл нөөцлөгдлөө.`);
}

/* ---------- Нөөцөөс сэргээх ---------- */
async function restoreAll(file){
  let pack;
  try{ pack = JSON.parse(await file.text()); }
  catch(e){ return toast("Файлыг уншиж чадсангүй. JSON нөөц файл сонгоно уу."); }
  if(!pack || !pack.db || !Array.isArray(pack.db.orgs)) return toast("Энэ файл энэ системийн нөөц биш байна.");
  const n = pack.db.orgs.length;
  openModal("Нөөцөөс сэргээх", `
    <div class="msg err">Одоогийн бүх өгөгдөл устаж, нөөц файлын өгөгдлөөр солигдоно. Энэ үйлдлийг буцаах боломжгүй.</div>
    <dl class="kv">
      <dt>Нөөц хийсэн огноо</dt><dd>${esc((pack.at||"").slice(0,16).replace("T"," "))}</dd>
      <dt>Нөөц дэх байгууллага</dt><dd>${n}</dd>
      <dt>Одоо системд байгаа</dt><dd>${DB.orgs.length}</dd>
    </dl>
    <p class="note">Солихоос өмнө одоогийн өгөгдлөө нөөцөлж авахыг зөвлөе.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    {label:"Сэргээх", cls:"danger", act:async (btn)=>{
      if(!btn.dataset.armed){ btn.dataset.armed="1"; btn.textContent="Сэргээхийг баталгаажуулах"; return; }
      DB = pack.db;
      if(!Array.isArray(DB.orgs)) DB.orgs = [];
      seedAdmins();                       // хуучин нөөцөд админы эрх байхгүй бол сэргээнэ
      await saveDB();
      for(const id of Object.keys(pack.media||{})) await saveMedia(id, pack.media[id]);
      for(const id of Object.keys(pack.staff||{})) await saveStaff(id, pack.staff[id], null);
      closeModal(); render(); toast(`${n} байгууллагын өгөгдөл сэргээгдлээ.`);
    }}
  ]);
}

/* ---------- CSV импорт ---------- */
const IMPORT_COLS = [
  ["Байгууллагын нэр","name"],["Байгууллагын регистр","reg"],["Үйл ажиллагааны чиглэл","cat"],["Өмчийн хэлбэр","own"],
  ["Хороо","khoroo"],["Хаяг","addr"],["Өргөрөг","lat"],["Уртраг","lng"],["Талбай (м²)","area"],
  ["Ажиллагсдын тоо (зарласан)","staff"],["Ажиллах цаг","hours"],["Гадна камер","camOut"],["Дотор камер","camIn"],
  ["Тусгай зөвшөөрөл","lic"],["Зөвшөөрөл дуусах","licEnd"],["Захирал","dir"],["Утас","phone"],["И-мэйл","mail"],
  ["Эхэлсэн огноо","since"],["Төлөв","status"],["Тэмдэглэл","note"]
];
const IMPORT_ALIAS = {
  "нэр":"name", "регистр":"reg", "регистрийн дугаар":"reg", "чиглэл":"cat", "өмч":"own",
  "дэлгэрэнгүй хаяг":"addr", "талбай":"area", "ажиллагсдын тоо":"staff",
  "ажиллах цагийн хуваарь":"hours", "тусгай зөвшөөрлийн дугаар":"lic",
  "захирал / эзэмшигч":"dir", "имэйл":"mail", "утасны дугаар":"phone"
};

function parseCSV(text){
  text = String(text).replace(/^﻿/, "");
  const first = text.split("\n")[0] || "";
  const d = (first.split(";").length > first.split(",").length) ? ";" : ",";
  const rows = []; let row = [], cell = "", q = false;
  for(let i=0;i<text.length;i++){
    const c = text[i];
    if(q){
      if(c === '"'){ if(text[i+1] === '"'){ cell += '"'; i++; } else q = false; }
      else cell += c;
    }else{
      if(c === '"') q = true;
      else if(c === d){ row.push(cell); cell = ""; }
      else if(c === "\n"){ row.push(cell); rows.push(row); row = []; cell = ""; }
      else if(c !== "\r") cell += c;
    }
  }
  if(cell !== "" || row.length){ row.push(cell); rows.push(row); }
  return rows.filter(r => r.some(x => String(x).trim() !== ""));
}

function csvTemplate(){
  const head = IMPORT_COLS.map(c=>`"${c[0]}"`).join(",");
  const demo = ['"Жишээ ХХК"','"6123456"',`"${CATS[0]}"`,`"${OWNERS[0]}"`,'"11"','"Чингисийн өргөн чөлөө, 5-р байр, 12 тоот"',
                '"47.906412"','"106.907318"','"120"','"8"','"09:00–21:00"','"4"','"6"','"ТЗ-2026/145"','"2027-05-30"',
                '"Б.Болд"','"99112233"','"info@жишээ.mn"','"2021-03-01"',`"${STATUSES[0]}"`,'""'].join(",");
  downloadBlob("﻿" + [head, demo].join("\r\n"), "text/csv;charset=utf-8;", "khanuul_import_zagvar.csv");
  toast("Загвар татагдлаа. Эхний мөрийн гарчгийг өөрчлөхгүй байх хэрэгтэй.");
}

async function importCSV(file){
  const rows = parseCSV(await file.text());
  if(rows.length < 2) return toast("Файлд мэдээлэл алга байна.");
  const head = rows[0].map(h => String(h).trim().toLowerCase());
  const idx = {};
  IMPORT_COLS.forEach(([label, key])=>{
    let i = head.indexOf(label.toLowerCase());
    if(i < 0) for(const a in IMPORT_ALIAS){ if(IMPORT_ALIAS[a] === key && head.indexOf(a) >= 0){ i = head.indexOf(a); break; } }
    if(i >= 0) idx[key] = i;
  });
  if(idx.name === undefined || idx.reg === undefined)
    return toast("“Байгууллагын нэр”, “Байгууллагын регистр” багана олдсонгүй. Загварыг ашиглана уу.");

  const get = (r, k) => idx[k] === undefined ? "" : String(r[idx[k]] ?? "").trim();
  const pick = (v, list, def) => list.includes(v) ? v : def;
  const pw1234 = await sha("1234");
  const added = [], skipped = [], bad = [];

  rows.slice(1).forEach((r, n) => {
    const name = get(r,"name"), reg = get(r,"reg");
    if(!name || !reg) return bad.push(`${n+2}-р мөр: нэр эсвэл регистр хоосон`);
    if(!/^\d{6,8}$/.test(reg)) return bad.push(`${n+2}-р мөр: регистр “${reg}” — 6–8 оронтой тоо байх ёстой`);
    if(DB.orgs.some(x=>x.reg===reg) || added.some(x=>x.reg===reg)) return skipped.push(`${name} (№${reg})`);
    let kh = parseInt(get(r,"khoroo"), 10); if(!(kh>=1 && kh<=25)) kh = 1;
    added.push({
      id:uid(), name, reg,
      cat:pick(get(r,"cat"), CATS, CATS[CATS.length-1]),
      own:pick(get(r,"own"), OWNERS, OWNERS[0]),
      district:"Хан-Уул", khoroo:kh, addr:get(r,"addr"),
      lat:/^-?\d{1,3}(\.\d+)?$/.test(get(r,"lat")) ? get(r,"lat") : "",
      lng:/^-?\d{1,3}(\.\d+)?$/.test(get(r,"lng")) ? get(r,"lng") : "",
      area:get(r,"area"), staff:get(r,"staff"), staffN:0,
      camOut:get(r,"camOut"), camIn:get(r,"camIn"), hours:get(r,"hours"),
      lic:get(r,"lic"), licEnd:/^\d{4}-\d{2}-\d{2}$/.test(get(r,"licEnd")) ? get(r,"licEnd") : "",
      dir:get(r,"dir"), phone:get(r,"phone"), mail:get(r,"mail"),
      since:/^\d{4}-\d{2}-\d{2}$/.test(get(r,"since")) ? get(r,"since") : "",
      status:pick(get(r,"status"), STATUSES, STATUSES[0]), note:get(r,"note"),
      appr:"ok", apprAt:today(), apprNote:"", pw:pw1234, created:today(), notices:[]
    });
  });

  const list = x => x.length ? `<ul style="margin:6px 0 0 18px;font-size:12.5px;line-height:1.6">${x.slice(0,15).map(t=>`<li>${esc(t)}</li>`).join("")}${x.length>15?`<li>…бусад ${x.length-15}</li>`:""}</ul>` : "";
  openModal("CSV импорт", `
    <dl class="kv">
      <dt>Нэмэгдэх шинэ бүртгэл</dt><dd><b>${added.length}</b></dd>
      <dt>Алгасах (регистр давхцсан)</dt><dd>${skipped.length}${list(skipped)}</dd>
      <dt>Алдаатай мөр</dt><dd>${bad.length}${list(bad)}</dd>
    </dl>
    <p class="note">Импортоор орсон байгууллага “Зөвшөөрөгдсөн” төлөвтэй, нууц үг нь <b>1234</b> байна. Тэд нэвтэрсний дараа нууц үгээ солино.</p>`, [
    {label:"Болих", cls:"ghost", act:closeModal},
    ...(added.length ? [{label:`${added.length} бүртгэл нэмэх`, cls:"", act:async ()=>{
      DB.orgs.push(...added); await saveDB(); await ensureNotices();
      closeModal(); render(); toast(`${added.length} байгууллага нэмэгдлээ.`);
    }}] : [])
  ]);
}

/* ---------- Газрын зураг ---------- */
let MAPOBJ = null, MAPLAYER = null;
function paintMap(){
  const host = $("#map"); if(!host) return;
  if(!window.L){
    host.innerHTML = `<p class="note" style="padding:16px">Газрын зургийн сан ачаалагдсангүй. Интернэт холболтоо шалгаад хуудсыг дахин ачаална уу.</p>`;
    return;
  }
  if(MAPOBJ && MAPOBJ.getContainer() !== host){ MAPOBJ.remove(); MAPOBJ = null; MAPLAYER = null; }
  if(!MAPOBJ){
    MAPOBJ = L.map(host).setView([47.8864, 106.8800], 12);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
      { maxZoom:19, attribution:"© OpenStreetMap" }).addTo(MAPOBJ);
  }
  if(MAPLAYER) MAPLAYER.remove();
  MAPLAYER = L.layerGroup().addTo(MAPOBJ);

  const pts = filtered().filter(o => o.lat && o.lng && !isNaN(+o.lat) && !isNaN(+o.lng));
  pts.forEach(o=>{
    const d = daysLeft(o.licEnd);
    const col = o.appr !== "ok" ? "#8A94B0"
              : (d !== null && d < 0)  ? "#A32331"
              : (d !== null && d <= 60) ? "#A3801A" : "#2E5AA8";
    const mk = L.circleMarker([+o.lat, +o.lng],
      { radius:7, color:"#fff", weight:2, fillColor:col, fillOpacity:.95 }).addTo(MAPLAYER);
    mk.bindPopup(
      `<b>${esc(o.name)}</b><br>№${esc(o.reg)} · ${esc(o.cat)}<br>${esc(o.khoroo)}-р хороо`
      + (o.addr ? `<br>${esc(o.addr)}` : "")
      + `<br><a href="#" data-mapopen="${o.id}">Дэлгэрэнгүй</a>`);
  });
  MAPOBJ.off("popupopen").on("popupopen", e=>{
    const a = e.popup.getElement().querySelector("[data-mapopen]");
    if(a) a.onclick = ev => { ev.preventDefault(); MAPOBJ.closePopup(); detail(a.dataset.mapopen); };
  });

  const note = $("#mapNote");
  if(note) note.innerHTML = pts.length
    ? `Зураг дээр <b>${pts.length}</b> нэгж байна (шүүлтийн дагуу). Өнгө: `
      + `<span class="pill ok">цэнхэр — хүчинтэй</span> `
      + `<span class="pill warn">шар — 60 хоногт дуусна</span> `
      + `<span class="pill bad">улаан — хугацаа дууссан</span> `
      + `<span class="pill neutral">саарал — хүлээгдэж буй</span>`
    : `Өргөрөг, уртраг оруулсан нэгж алга байна. “Мэдээлэл засах” хэсгээс солбицол оруулбал энд харагдана.`;

  if(pts.length) MAPOBJ.fitBounds(L.latLngBounds(pts.map(o=>[+o.lat, +o.lng])).pad(.25));
  setTimeout(()=>{ try{ MAPOBJ.invalidateSize(); }catch(e){} }, 80);
}

/* ---------- Анкет (зурагтай, хэвлэхэд бэлэн) ---------- */
async function downloadAnket(o){
  toast("Анкет бэлтгэж байна…");
  const m = await loadMedia(o.id);
  const stf = await loadStaff(o.id);
  const row = (k,v) => `<tr><th>${esc(k)}</th><td>${v ? esc(v) : "—"}</td></tr>`;
  const photos2    = m.photos.slice(0, 2);                 // үндсэн мэдээллийн доор 2 зураг
  const restPhotos = m.photos.slice(2);                    // үлдсэнийг нэмэлт хэсэгт
  const licImgs    = m.lics.filter(L => L.data.startsWith("data:image"));
  const licFiles   = m.lics.filter(L => !L.data.startsWith("data:image"));
  const html = `<!DOCTYPE html><html lang="mn"><head><meta charset="utf-8">
<title>Анкет — ${esc(o.name)}</title>
<style>
  @page{size:A4;margin:14mm}
  *{box-sizing:border-box}
  body{font-family:"Segoe UI",Arial,sans-serif;color:#15203A;margin:0;padding:18px;font-size:12.5px;line-height:1.5}
  .sheet{max-width:820px;margin:0 auto}
  .head{border-bottom:3px solid #A3801A;padding-bottom:12px;margin-bottom:18px}
  .head .org{font-size:12px;color:#6A7391;letter-spacing:.02em}
  .head h1{font-size:20px;margin:8px 0 4px}
  .head .meta{font-size:12px;color:#6A7391}
  h2{font-size:13.5px;margin:22px 0 8px;padding-bottom:5px;border-bottom:1px solid #D6DAE6}
  table{width:100%;border-collapse:collapse;margin-bottom:6px}
  th,td{border:1px solid #D6DAE6;padding:7px 10px;text-align:left;vertical-align:top}
  th{width:230px;background:#F4F6FB;font-weight:600;color:#4A5474}
  .imgs{display:flex;flex-wrap:wrap;gap:10px}
  .imgs img{width:48.5%;border:1px solid #D6DAE6;object-fit:cover;aspect-ratio:4/3}
  .imgs .cap{width:48.5%;font-size:10.5px;color:#6A7391;text-align:center}
  .lic{display:flex;flex-wrap:wrap;gap:10px}
  .lic img{width:48.5%;border:1px solid #D6DAE6;object-fit:contain;background:#fff}
  .sign{display:flex;justify-content:space-between;margin-top:34px;font-size:12px}
  .sign div{width:45%;border-top:1px solid #15203A;padding-top:6px;color:#4A5474}
  .foot{margin-top:24px;font-size:11px;color:#6A7391;border-top:1px solid #D6DAE6;padding-top:8px}
  @media print{ body{padding:0} .noprint{display:none} }
</style></head><body><div class="sheet">
  <div class="head">
    <div class="org">${esc(SITE_NAME)}</div>
    <h1>Аж ахуйн нэгж, байгууллагын бүртгэлийн анкет</h1>
    <div class="meta">Хэвлэсэн огноо: ${today()} · Байгууллагын регистр: ${esc(o.reg)} · Төлөв: ${esc(APPR[o.appr]||"")}</div>
  </div>

  <h2>1. Үндсэн мэдээлэл</h2>
  <table>
    ${row("Байгууллагын нэр", o.name)}
    ${row("Байгууллагын регистр", o.reg)}
    ${row("Үйл ажиллагааны чиглэл", o.cat)}
    ${row("Өмчийн хэлбэр", o.own)}
    ${row("Үйл ажиллагаа эхэлсэн огноо", o.since)}
    ${row("Үйл ажиллагааны төлөв", o.status)}
  </table>
  ${photos2.length ? `<div class="imgs">
      ${photos2.map((p,i)=>`<img src="${p}" alt="Байгууллагын зураг ${i+1}">`).join("")}
      ${photos2.map((p,i)=>`<div class="cap">Зураг ${i+1}</div>`).join("")}
    </div>` : `<p>Байгууллагын зураг хавсаргаагүй.</p>`}

  <h2>2. Холбоо барих</h2>
  <table>
    ${row("Захирал / эзэмшигч", o.dir)}
    ${row("Утас", o.phone)}
    ${row("И-мэйл", o.mail)}
  </table>

  <h2>3. Байршил, хүчин чадал</h2>
  <table>
    ${row("Дүүрэг, хороо", `${o.district} дүүрэг, ${o.khoroo}-р хороо`)}
    ${row("Дэлгэрэнгүй хаяг", o.addr)}
    ${row("Өргөрөг (latitude)", o.lat)}
    ${row("Уртраг (longitude)", o.lng)}
    ${row("Үйл ажиллагааны талбай", o.area ? o.area+" м²" : "")}
    ${row("Ажиллагсдын тоо", o.staff)}
    ${row("Ажиллах цагийн хуваарь", o.hours)}
    ${row("Хяналтын камер", `Гадна ${o.camOut||0} ш · Дотор ${o.camIn||0} ш · Нийт ${(Number(o.camOut)||0)+(Number(o.camIn)||0)} ш`)}
  </table>

  <h2>4. Тусгай зөвшөөрөл</h2>
  <table>
    ${row("Зөвшөөрлийн дугаар", o.lic)}
    ${row("Дуусах огноо", o.licEnd)}
    ${row("Нөхцөл байдал", o.licEnd ? (daysLeft(o.licEnd)<0 ? "Хугацаа дууссан" : "Хүчинтэй, "+daysLeft(o.licEnd)+" хоног үлдсэн") : "Бүртгээгүй")}
    ${row("Хавсаргасан баримтын тоо", String(m.lics.length))}
  </table>
  ${licImgs.length ? `<div class="lic">${licImgs.map((L,i)=>`<img src="${L.data}" alt="Тусгай зөвшөөрөл ${i+1}">`).join("")}</div>` : ""}
  ${licFiles.length ? `<p>Зурган бус баримт: ${licFiles.map(L=>esc(L.name)).join(", ")} (тусад нь хавсаргав)</p>` : ""}
  ${!m.lics.length ? `<p>Зөвшөөрлийн баримт хавсаргаагүй.</p>` : ""}

  <h2>5. Ажилчдын бүртгэл</h2>
  ${stf.length ? `<table>
    <tr><th style="width:auto;text-align:left">Зураг</th><th style="width:auto;text-align:left">Овог нэр</th><th style="width:auto">Регистрийн дугаар</th><th style="width:auto">Албан тушаал</th><th style="width:auto">Утас</th><th style="width:auto">Ажилд орсон</th><th style="width:auto">Гэрийн хаяг</th><th style="width:auto">Төлөв</th></tr>
    ${stf.map(st=>`<tr><td>${st.photo?`<img src="${st.photo}" style="width:42px;aspect-ratio:3/4;object-fit:cover;border:1px solid #D6DAE6">`:"—"}</td><td>${esc(st.name)}</td><td>${esc(st.reg)||"—"}</td><td>${esc(st.pos)}</td><td>${esc(st.phone)||"—"}</td><td>${esc(st.since)||"—"}</td><td>${esc(st.addr)||"—"}</td><td>${esc(st.status)}</td></tr>`).join("")}
  </table><p>Нийт ${stf.length} ажилтан, үүнээс ажиллаж байгаа ${stf.filter(x=>x.status!=="Чөлөөлөгдсөн").length}.</p>` : `<p>Ажилтан бүртгээгүй.</p>`}

  ${restPhotos.length ? `<h2>6. Нэмэлт зураг</h2><div class="imgs">${restPhotos.map((p,i)=>`<img src="${p}" alt="Нэмэлт зураг ${i+1}">`).join("")}</div>` : ""}

  ${o.note ? `<h2>${restPhotos.length?7:6}. Тэмдэглэл</h2><p>${esc(o.note)}</p>` : ""}

  <div class="sign">
    <div>Байгууллагын төлөөлөгч: ................................</div>
    <div>Бүртгэсэн ажилтан: ................................</div>
  </div>
  <div class="foot">Энэ анкет нь ${esc(SITE_NAME)}-аас автоматаар үүсгэсэн баримт юм.
  PDF болгохын тулд энэ файлыг браузераар нээж, хэвлэх цонхноос “PDF болгож хадгалах” сонголтыг ашиглана уу.</div>
</div></body></html>`;
  downloadBlob(html, "text/html;charset=utf-8", `anket_${o.reg}_${o.name.replace(/[^\wА-Яа-яӨөҮү]+/g,"_").slice(0,30)}.html`);
  toast("Анкет татагдлаа. Браузераар нээж PDF болгоно.");
}

/* ---------- Эхлүүлэх ---------- */
(async function init(){
  fillSelect($("#rg_cat"), CATS);
  fillSelect($("#rg_own"), OWNERS);
  fillSelect($("#rg_khoroo"), KHOROOS.map(String));
  attachPwToggles(document);
  await loadDB();
  await ensureNotices();
  renderAuthStats();
})();
